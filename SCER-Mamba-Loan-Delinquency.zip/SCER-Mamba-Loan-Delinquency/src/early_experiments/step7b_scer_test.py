import numpy as np
import torch
import torch.nn as nn
import joblib

from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix
)


# ============================================================
# PATHS
# ============================================================

DATA_DIR = "Data/sequential_model_ready"

MODEL_PATH = "output/scer/best_scer_pre_mamba.pt"
THRESHOLD_PATH = "output/scer/best_scer_threshold.pkl"


# ============================================================
# EXACT SCER PRE-MAMBA MODEL
# ============================================================

class SCERPreMamba(nn.Module):

    def __init__(
        self,
        temporal_features=7,
        static_features=12,
        hidden_dim=32
    ):
        super().__init__()

        self.static_encoder = nn.Sequential(
            nn.Linear(static_features, 32),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(32, hidden_dim),
            nn.ReLU()
        )

        self.condition_gamma = nn.Linear(
            hidden_dim,
            temporal_features
        )

        self.condition_beta = nn.Linear(
            hidden_dim,
            temporal_features
        )

        self.temporal_encoder = nn.GRU(
            input_size=temporal_features,
            hidden_size=hidden_dim,
            num_layers=1,
            batch_first=True
        )

        self.temporal_attention = nn.Linear(
            hidden_dim,
            hidden_dim
        )

        self.risk_projection = nn.Linear(
            1,
            hidden_dim
        )

        self.attention_score = nn.Linear(
            hidden_dim,
            1
        )

        self.fusion_gate = nn.Linear(
            hidden_dim * 2,
            hidden_dim
        )

        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, 32),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(32, 1)
        )


    def forward(self, sequence, static):

        # Static encoding
        static_embedding = self.static_encoder(
            static
        )

        # Static conditioning
        gamma = torch.tanh(
            self.condition_gamma(
                static_embedding
            )
        )

        beta = self.condition_beta(
            static_embedding
        )

        gamma = gamma.unsqueeze(1)
        beta = beta.unsqueeze(1)

        conditioned_sequence = (
            sequence * (1.0 + gamma) + beta
        )

        # GRU temporal encoder
        temporal_output, _ = (
            self.temporal_encoder(
                conditioned_sequence
            )
        )

        # Risk event signal
        risk_event_signal = (
            sequence[:, :, 4]
            + sequence[:, :, 5]
            + sequence[:, :, 6]
        ).unsqueeze(-1)

        # Risk-event attention
        temporal_attention = (
            self.temporal_attention(
                temporal_output
            )
        )

        risk_attention = (
            self.risk_projection(
                risk_event_signal
            )
        )

        attention_energy = torch.tanh(
            temporal_attention
            + risk_attention
        )

        attention_logits = (
            self.attention_score(
                attention_energy
            ).squeeze(-1)
        )

        attention_weights = torch.softmax(
            attention_logits,
            dim=1
        )

        temporal_context = torch.sum(
            temporal_output
            * attention_weights.unsqueeze(-1),
            dim=1
        )

        # Adaptive gated fusion
        fusion_input = torch.cat(
            [
                temporal_context,
                static_embedding
            ],
            dim=1
        )

        gate = torch.sigmoid(
            self.fusion_gate(
                fusion_input
            )
        )

        fused_representation = (
            gate * temporal_context
            + (1.0 - gate) * static_embedding
        )

        # Prediction
        logits = self.classifier(
            fused_representation
        ).squeeze(1)

        return (
            logits,
            attention_weights,
            gate
        )


# ============================================================
# LOAD TEST DATA
# ============================================================

print("Loading SCER test data...")

X_sequence_test = np.load(
    f"{DATA_DIR}/X_sequence_test.npy"
)

X_static_test = np.load(
    f"{DATA_DIR}/X_static_test.npy"
)

y_test = np.load(
    f"{DATA_DIR}/y_test.npy"
)

print("Sequence:", X_sequence_test.shape)
print("Static:", X_static_test.shape)
print("Target:", y_test.shape)


# ============================================================
# LOAD MODEL
# ============================================================

device = torch.device(
    "cuda" if torch.cuda.is_available()
    else "cpu"
)

print("Device:", device)

model = SCERPreMamba().to(device)

state_dict = torch.load(
    MODEL_PATH,
    map_location=device
)

model.load_state_dict(
    state_dict
)

model.eval()

print("SCER pre-Mamba model loaded successfully")


# ============================================================
# LOAD VALIDATION-SELECTED THRESHOLD
# ============================================================

threshold = joblib.load(
    THRESHOLD_PATH
)

print("Saved threshold:", threshold)


# ============================================================
# TEST PREDICTIONS
# ============================================================

probabilities = []

batch_size = 1024

with torch.no_grad():

    for start in range(
        0,
        len(X_sequence_test),
        batch_size
    ):

        end = start + batch_size

        sequence_batch = torch.tensor(
            X_sequence_test[start:end],
            dtype=torch.float32,
            device=device
        )

        static_batch = torch.tensor(
            X_static_test[start:end],
            dtype=torch.float32,
            device=device
        )

        logits, attention, gate = model(
            sequence_batch,
            static_batch
        )

        probs = torch.sigmoid(
            logits
        )

        probabilities.extend(
            probs.cpu().numpy()
        )


probabilities = np.asarray(
    probabilities
)

predictions = (
    probabilities >= threshold
).astype(int)


# ============================================================
# METRICS
# ============================================================

precision = precision_score(
    y_test,
    predictions,
    zero_division=0
)

recall = recall_score(
    y_test,
    predictions,
    zero_division=0
)

f1 = f1_score(
    y_test,
    predictions,
    zero_division=0
)

roc_auc = roc_auc_score(
    y_test,
    probabilities
)

pr_auc = average_precision_score(
    y_test,
    probabilities
)

tn, fp, fn, tp = confusion_matrix(
    y_test,
    predictions
).ravel()


# ============================================================
# PRINT RESULTS
# ============================================================

print("\n========================================")
print("FINAL SCER PRE-MAMBA TEST RESULTS")
print("========================================")

print(f"Threshold : {threshold:.2f}")
print(f"Precision : {precision:.4f}")
print(f"Recall    : {recall:.4f}")
print(f"F1 Score  : {f1:.4f}")
print(f"ROC-AUC   : {roc_auc:.4f}")
print(f"PR-AUC    : {pr_auc:.4f}")

print("\nConfusion Matrix")

print("TP:", tp)
print("FP:", fp)
print("FN:", fn)
print("TN:", tn)


# ============================================================
# SAVE RESULTS
# ============================================================

results = {
    "threshold": float(threshold),
    "precision": float(precision),
    "recall": float(recall),
    "f1": float(f1),
    "roc_auc": float(roc_auc),
    "pr_auc": float(pr_auc),
    "TP": int(tp),
    "FP": int(fp),
    "FN": int(fn),
    "TN": int(tn)
}

joblib.dump(
    results,
    "output/scer/scer_pre_mamba_test_metrics.pkl"
)

print("\nSCER pre-Mamba test metrics saved.")