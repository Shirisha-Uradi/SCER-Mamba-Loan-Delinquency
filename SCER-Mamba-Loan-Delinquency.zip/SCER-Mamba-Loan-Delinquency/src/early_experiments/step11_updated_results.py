import pandas as pd
import os

os.makedirs("output/final_results", exist_ok=True)

results = [
    {
        "Model": "LSTM Baseline",
        "Accuracy": 0.9880,
        "Precision": 0.3158,
        "Recall": 0.3684,
        "F1": 0.3401,
        "ROC_AUC": 0.8564,
        "PR_AUC": 0.1887
    },
    {
        "Model": "SCER Pre-Mamba",
        "Accuracy": 0.9861,
        "Precision": 0.2533,
        "Recall": 0.3377,
        "F1": 0.2895,
        "ROC_AUC": 0.8555,
        "PR_AUC": 0.1770
    },
    {
        "Model": "SCER-Mamba V2",
        "Accuracy": 0.9882,
        "Precision": 0.2957,
        "Recall": 0.2982,
        "F1": 0.2969,
        "ROC_AUC": 0.8530,
        "PR_AUC": 0.1694
    },
    {
        "Model": "Sampler + Focal Loss",
        "Accuracy": 0.9879,
        "Precision": 0.2964,
        "Recall": 0.3289,
        "F1": 0.3119,
        "ROC_AUC": 0.8477,
        "PR_AUC": 0.1647
    },
    {
        "Model": "Sampler Only",
        "Accuracy": 0.9887,
        "Precision": 0.3015,
        "Recall": 0.2632,
        "F1": 0.2810,
        "ROC_AUC": 0.8488,
        "PR_AUC": 0.1598
    },
    {
        "Model": "Focal Loss Only",
        "Accuracy": 0.9883,
        "Precision": 0.3125,
        "Recall": 0.3289,
        "F1": 0.3205,
        "ROC_AUC": 0.8576,
        "PR_AUC": 0.1789
    },
    {
        "Model": "Experiment C - No Gate",
        "Accuracy": 0.9868,
        "Precision": 0.2838,
        "Recall": 0.3772,
        "F1": 0.3239,
        "ROC_AUC": 0.8579,
        "PR_AUC": 0.1726
    },
    {
        "Model": "Experiment D - No Static Conditioning",
        "Accuracy": 0.9879,
        "Precision": 0.3042,
        "Recall": 0.3509,
        "F1": 0.3259,
        "ROC_AUC": 0.8609,
        "PR_AUC": 0.1823
    },
    {
        "Model": "Experiment E - No Conditioning + No Gate",
        "Accuracy": 0.9884,
        "Precision": 0.3100,
        "Recall": 0.3114,
        "F1": 0.3107,
        "ROC_AUC": 0.8553,
        "PR_AUC": 0.1776
    },
    {
        "Model": "Final Experiment D - 3 Seed Mean",
        "Accuracy": 0.987795,
        "Precision": 0.294289,
        "Recall": 0.327485,
        "F1": 0.309663,
        "ROC_AUC": 0.855797,
        "PR_AUC": 0.182235
    }
]

df = pd.DataFrame(results)

print(df)

df.to_csv(
    "output/final_results/updated_complete_model_results.csv",
    index=False
)

print("\nSaved:")
print("output/final_results/updated_complete_model_results.csv")