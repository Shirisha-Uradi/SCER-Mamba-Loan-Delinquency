import pandas as pd
import numpy as np
import joblib
import os

from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)

# ============================================================
# STEP 4.6 - RANDOM FOREST THRESHOLD OPTIMISATION
# ============================================================

validation_file = "Data/model_ready/validation_normalised.csv"
model_file = "output/models/random_forest_model.pkl"
features_file = "Data/model_ready/model_features.pkl"

output_folder = "output/models"

print("========================================")
print("STEP 4.6 - RF THRESHOLD OPTIMISATION")
print("========================================")


# ============================================================
# 1. LOAD DATA
# ============================================================

val_df = pd.read_csv(
    validation_file,
    low_memory=False
)

features = joblib.load(
    features_file
)

model = joblib.load(
    model_file
)

X_val = val_df[features]
y_val = val_df["target_risk_6m"]


# ============================================================
# 2. PREDICT PROBABILITIES
# ============================================================

probabilities = model.predict_proba(
    X_val
)[:, 1]


# ============================================================
# 3. SEARCH THRESHOLDS
# ============================================================

thresholds = np.arange(
    0.05,
    1.00,
    0.01
)

results = []

for threshold in thresholds:

    predictions = (
        probabilities >= threshold
    ).astype(int)

    precision = precision_score(
        y_val,
        predictions,
        zero_division=0
    )

    recall = recall_score(
        y_val,
        predictions,
        zero_division=0
    )

    f1 = f1_score(
        y_val,
        predictions,
        zero_division=0
    )

    tn, fp, fn, tp = confusion_matrix(
        y_val,
        predictions,
        labels=[0, 1]
    ).ravel()

    results.append({
        "Threshold": round(float(threshold), 2),
        "Precision": precision,
        "Recall": recall,
        "F1": f1,
        "True_Positive": tp,
        "False_Positive": fp,
        "False_Negative": fn,
        "True_Negative": tn
    })


# ============================================================
# 4. SORT BY F1
# ============================================================

results_df = pd.DataFrame(
    results
)

results_df = results_df.sort_values(
    "F1",
    ascending=False
).reset_index(drop=True)


print("\n========================================")
print("TOP 10 RF THRESHOLDS")
print("========================================")

print(
    results_df.head(10).to_string(
        index=False
    )
)


# ============================================================
# 5. BEST THRESHOLD
# ============================================================

best = results_df.iloc[0]

print("\n========================================")
print("BEST RANDOM FOREST THRESHOLD")
print("========================================")

print("Threshold:", best["Threshold"])
print("Precision:", round(best["Precision"], 4))
print("Recall:", round(best["Recall"], 4))
print("F1:", round(best["F1"], 4))

print(
    "True Positives:",
    int(best["True_Positive"])
)

print(
    "False Positives:",
    int(best["False_Positive"])
)

print(
    "False Negatives:",
    int(best["False_Negative"])
)

print(
    "True Negatives:",
    int(best["True_Negative"])
)


# ============================================================
# 6. SAVE
# ============================================================

results_df.to_csv(
    f"{output_folder}/rf_threshold_comparison.csv",
    index=False
)

joblib.dump(
    float(best["Threshold"]),
    f"{output_folder}/best_rf_threshold.pkl"
)

print("\n========================================")
print("STEP 4.6 COMPLETED")
print("========================================")