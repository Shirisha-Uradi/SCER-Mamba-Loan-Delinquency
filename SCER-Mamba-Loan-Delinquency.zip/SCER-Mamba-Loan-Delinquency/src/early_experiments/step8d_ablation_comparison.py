import joblib
import pandas as pd

# Load results
full_scer = joblib.load(
    "output/scer/scer_pre_mamba_test_metrics.pkl"
)

no_static = joblib.load(
    "output/ablation/no_static_conditioning_test_metrics.pkl"
)

no_risk = joblib.load(
    "output/ablation/no_risk_attention_test_metrics.pkl"
)

no_gate = joblib.load(
    "output/ablation/no_gated_fusion_test_metrics.pkl"
)

rows = [
    {
        "Model": "Full SCER",
        **full_scer
    },
    {
        "Model": "No Static Conditioning",
        **no_static
    },
    {
        "Model": "No Risk-Event Attention",
        **no_risk
    },
    {
        "Model": "No Adaptive Gated Fusion",
        **no_gate
    }
]

df = pd.DataFrame(rows)

columns = [
    "Model",
    "threshold",
    "precision",
    "recall",
    "f1",
    "roc_auc",
    "pr_auc",
    "TP",
    "FP",
    "FN",
    "TN"
]

df = df[columns]

print("\nFINAL ABLATION STUDY")
print("=" * 100)

print(
    df.to_string(
        index=False
    )
)

df.to_csv(
    "output/ablation/ablation_comparison.csv",
    index=False
)

print(
    "\nSaved: output/ablation/ablation_comparison.csv"
)

print("\nSTEP 8 COMPLETED")