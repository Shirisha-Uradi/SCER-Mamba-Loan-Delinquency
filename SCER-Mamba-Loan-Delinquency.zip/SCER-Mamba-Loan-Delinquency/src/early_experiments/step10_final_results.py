import pandas as pd

results = [
    {
        "Model": "LSTM Baseline",
        "Accuracy": 0.9880,
        "Precision": 0.3158,
        "Recall": 0.3684,
        "F1": 0.3401,
        "ROC_AUC": 0.8564,
        "PR_AUC": 0.1887
    },
    {
        "Model": "SCER Pre-Mamba",
        "Accuracy": 0.9861,
        "Precision": 0.2533,
        "Recall": 0.3377,
        "F1": 0.2895,
        "ROC_AUC": 0.8555,
        "PR_AUC": 0.1770
    },
    {
        "Model": "SCER-Mamba V2",
        "Accuracy": 0.9882,
        "Precision": 0.2957,
        "Recall": 0.2982,
        "F1": 0.2969,
        "ROC_AUC": 0.8530,
        "PR_AUC": 0.1694
    },
    {
        "Model": "Final SCER-Mamba (Experiment D - Mean 3 Seeds)",
        "Accuracy": 0.9878,
        "Precision": 0.2943,
        "Recall": 0.3275,
        "F1": 0.3097,
        "ROC_AUC": 0.8558,
        "PR_AUC": 0.1822
    }
]

df = pd.DataFrame(results)

print(df)

df.to_csv(
    "output/final_results/final_sequential_model_comparison.csv",
    index=False
)

print("\nSaved:")
print("output/final_results/final_sequential_model_comparison.csv")