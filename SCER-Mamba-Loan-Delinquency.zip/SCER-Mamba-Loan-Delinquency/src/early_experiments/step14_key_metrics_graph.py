import os
import pandas as pd
import matplotlib.pyplot as plt

input_path = r"output/final_results_v2/j18_j24_heldout_test_results.csv"
output_path = r"output/final_results_v2/j18_j24_key_metrics.png"

df = pd.read_csv(input_path)

metrics = [
    "PR_AUC",
    "ROC_AUC",
    "F1"
]

plot_df = df.copy()

for metric in metrics:
    plot_df[metric] = plot_df[metric] * 100

plot_df["Label"] = (
    plot_df["Cohort"]
    + " "
    + plot_df["Model"]
)

ax = plot_df.set_index("Label")[metrics].plot(
    kind="bar",
    figsize=(10, 6)
)

plt.title(
    "SCER-Mamba vs LSTM: Key Held-Out Test Metrics"
)

plt.ylabel("Score (%)")
plt.xlabel("")

plt.xticks(
    rotation=15,
    ha="right"
)

plt.ylim(0, 100)

plt.legend(
    title="Metric"
)

plt.tight_layout()

plt.savefig(
    output_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Key metrics graph saved:")
print(output_path)