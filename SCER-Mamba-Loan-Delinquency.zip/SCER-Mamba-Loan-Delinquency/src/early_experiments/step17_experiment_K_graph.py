import pandas as pd
import matplotlib.pyplot as plt

input_path = (
    r"output/final_results_v2/"
    r"experiment_K_validation_comparison.csv"
)

output_path = (
    r"output/final_results_v2/"
    r"experiment_K_validation_comparison.png"
)

df = pd.read_csv(input_path)

metrics = [
    "PR_AUC",
    "ROC_AUC",
    "F1"
]

plot_df = df.copy()

for metric in metrics:
    plot_df[metric] = plot_df[metric] * 100

ax = plot_df.set_index("Model")[metrics].plot(
    kind="bar",
    figsize=(11, 7)
)

plt.title(
    "Experiment K Validation Performance"
)

plt.ylabel("Score (%)")
plt.xlabel("")

plt.xticks(
    rotation=12,
    ha="right"
)

plt.ylim(0, 100)

plt.legend(
    title="Metric"
)

for container in ax.containers:
    ax.bar_label(
        container,
        fmt="%.1f",
        padding=2,
        fontsize=8
    )

plt.tight_layout()

plt.savefig(
    output_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Experiment K graph saved:")
print(output_path)