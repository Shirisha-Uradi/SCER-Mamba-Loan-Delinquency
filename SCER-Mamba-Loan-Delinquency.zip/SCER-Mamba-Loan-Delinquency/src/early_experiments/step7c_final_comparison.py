import pandas as pd

results = {
    "Model": [
        "LSTM",
        "SCER Pre-Mamba",
        "SCER-Mamba V2"
    ],

    "Precision": [
        0.3158,
        0.2533,
        0.2957
    ],

    "Recall": [
        0.3684,
        0.3377,
        0.2982
    ],

    "F1": [
        0.3401,
        0.2895,
        0.2969
    ],

    "ROC_AUC": [
        0.8564,
        0.8555,
        0.8530
    ],

    "PR_AUC": [
        0.1887,
        0.1770,
        0.1694
    ],

    "TP": [
        84,
        77,
        68
    ],

    "FP": [
        182,
        227,
        162
    ],

    "FN": [
        144,
        151,
        160
    ],

    "TN": [
        26847,
        26802,
        26867
    ]
}

df = pd.DataFrame(results)

print("\nFINAL MODEL COMPARISON")
print("=" * 80)

print(df.to_string(index=False))

df.to_csv(
    "output/final_model_comparison.csv",
    index=False
)

print(
    "\nSaved: output/final_model_comparison.csv"
)