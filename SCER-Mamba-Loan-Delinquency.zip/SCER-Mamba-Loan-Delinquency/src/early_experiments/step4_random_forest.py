import pandas as pd
import joblib
import os

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
    classification_report
)

# ============================================================
# STEP 4.5 - RANDOM FOREST BASELINE
# ============================================================

train_file = "Data/model_ready/train_normalised.csv"
val_file = "Data/model_ready/validation_normalised.csv"
features_file = "Data/model_ready/model_features.pkl"

output_folder = "output/models"
os.makedirs(output_folder, exist_ok=True)

print("========================================")
print("STEP 4.5 - RANDOM FOREST BASELINE")
print("========================================")


# ============================================================
# 1. LOAD DATA
# ============================================================

train_df = pd.read_csv(
    train_file,
    low_memory=False
)

val_df = pd.read_csv(
    val_file,
    low_memory=False
)

features = joblib.load(
    features_file
)

print("\nTraining rows:", len(train_df))
print("Validation rows:", len(val_df))
print("Features:", len(features))


# ============================================================
# 2. PREPARE DATA
# ============================================================

X_train = train_df[features]
y_train = train_df["target_risk_6m"]

X_val = val_df[features]
y_val = val_df["target_risk_6m"]


print("\nTraining target:")
print(
    y_train.value_counts().sort_index()
)

print("\nValidation target:")
print(
    y_val.value_counts().sort_index()
)


# ============================================================
# 3. TRAIN RANDOM FOREST
# ============================================================

print("\nTraining Random Forest...")

rf_model = RandomForestClassifier(
    n_estimators=300,
    max_depth=12,
    min_samples_leaf=5,
    class_weight="balanced",
    random_state=42,
    n_jobs=-1
)

rf_model.fit(
    X_train,
    y_train
)

print("Random Forest training completed.")


# ============================================================
# 4. VALIDATION PROBABILITIES
# ============================================================

val_probability = rf_model.predict_proba(
    X_val
)[:, 1]


# Default threshold initially
threshold = 0.50

val_prediction = (
    val_probability >= threshold
).astype(int)


# ============================================================
# 5. METRICS
# ============================================================

accuracy = accuracy_score(
    y_val,
    val_prediction
)

precision = precision_score(
    y_val,
    val_prediction,
    zero_division=0
)

recall = recall_score(
    y_val,
    val_prediction,
    zero_division=0
)

f1 = f1_score(
    y_val,
    val_prediction,
    zero_division=0
)

roc_auc = roc_auc_score(
    y_val,
    val_probability
)

pr_auc = average_precision_score(
    y_val,
    val_probability
)


print("\n========================================")
print("RANDOM FOREST VALIDATION METRICS")
print("========================================")

print("Accuracy:", round(accuracy, 4))
print("Precision:", round(precision, 4))
print("Recall:", round(recall, 4))
print("F1-score:", round(f1, 4))
print("ROC-AUC:", round(roc_auc, 4))
print("PR-AUC:", round(pr_auc, 4))


# ============================================================
# 6. CONFUSION MATRIX
# ============================================================

cm = confusion_matrix(
    y_val,
    val_prediction,
    labels=[0, 1]
)

tn, fp, fn, tp = cm.ravel()

print("\n========================================")
print("CONFUSION MATRIX")
print("========================================")

print("True Negatives:", tn)
print("False Positives:", fp)
print("False Negatives:", fn)
print("True Positives:", tp)


# ============================================================
# 7. CLASSIFICATION REPORT
# ============================================================

print("\n========================================")
print("CLASSIFICATION REPORT")
print("========================================")

print(
    classification_report(
        y_val,
        val_prediction,
        digits=4,
        zero_division=0
    )
)


# ============================================================
# 8. FEATURE IMPORTANCE
# ============================================================

importance_df = pd.DataFrame({
    "Feature": features,
    "Importance": rf_model.feature_importances_
})

importance_df = importance_df.sort_values(
    "Importance",
    ascending=False
)

print("\n========================================")
print("TOP FEATURES")
print("========================================")

print(
    importance_df.head(10).to_string(
        index=False
    )
)


# ============================================================
# 9. SAVE METRICS
# ============================================================

metrics_df = pd.DataFrame({
    "Metric": [
        "Accuracy",
        "Precision",
        "Recall",
        "F1",
        "ROC_AUC",
        "PR_AUC"
    ],
    "Value": [
        accuracy,
        precision,
        recall,
        f1,
        roc_auc,
        pr_auc
    ]
})

metrics_df.to_csv(
    f"{output_folder}/random_forest_validation_metrics.csv",
    index=False
)

importance_df.to_csv(
    f"{output_folder}/random_forest_feature_importance.csv",
    index=False
)


# ============================================================
# 10. SAVE MODEL
# ============================================================

joblib.dump(
    rf_model,
    f"{output_folder}/random_forest_model.pkl"
)


print("\n========================================")
print("STEP 4.5 COMPLETED")
print("========================================")

print(
    "Model saved:",
    f"{output_folder}/random_forest_model.pkl"
)

print(
    "Metrics saved:",
    f"{output_folder}/random_forest_validation_metrics.csv"
)