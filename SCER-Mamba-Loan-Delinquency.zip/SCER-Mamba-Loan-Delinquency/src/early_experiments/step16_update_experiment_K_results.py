import os
import pandas as pd

BASE = r"output/final_results_v2"
K_FOLDER = os.path.join(
    BASE,
    "Experiment_K_Final"
)

k_path = os.path.join(
    K_FOLDER,
    "experiment_K_reproducibility.csv"
)

df = pd.read_csv(k_path)

# ============================================================
# COMPUTE REPRODUCIBILITY SUMMARY
# ============================================================

metrics = [
    "pr_auc",
    "roc_auc",
    "f1"
]

mean_values = df[metrics].mean()
std_values = df[metrics].std()

summary = pd.DataFrame([
    {
        "Model": "Experiment K Multi-Pool SCER-Mamba",
        "PR_AUC_Mean": mean_values["pr_auc"],
        "PR_AUC_SD": std_values["pr_auc"],
        "ROC_AUC_Mean": mean_values["roc_auc"],
        "ROC_AUC_SD": std_values["roc_auc"],
        "F1_Mean": mean_values["f1"],
        "F1_SD": std_values["f1"]
    }
])

summary_path = os.path.join(
    BASE,
    "experiment_K_reproducibility_summary.csv"
)

summary.to_csv(
    summary_path,
    index=False
)

# ============================================================
# VALIDATION COMPARISON
# ============================================================

comparison = pd.DataFrame([
    {
        "Model": "Original J24 SCER-Mamba",
        "PR_AUC": 0.29589391918814717,
        "ROC_AUC": 0.9077882825350673,
        "F1": 0.40397350988488495
    },
    {
        "Model": "Experiment K SCER-Mamba",
        "PR_AUC": mean_values["pr_auc"],
        "ROC_AUC": mean_values["roc_auc"],
        "F1": mean_values["f1"]
    },
    {
        "Model": "J24 LSTM",
        "PR_AUC": 0.315214122767998,
        "ROC_AUC": 0.9103398226991063,
        "F1": 0.4101694914762534
    }
])

comparison_path = os.path.join(
    BASE,
    "experiment_K_validation_comparison.csv"
)

comparison.to_csv(
    comparison_path,
    index=False
)

print("\n======================================")
print("EXPERIMENT K FINAL SUMMARY")
print("======================================")

print("\n3-SEED RESULTS:")
print(df)

print("\nMEAN:")
print(mean_values)

print("\nSTANDARD DEVIATION:")
print(std_values)

print("\nVALIDATION COMPARISON:")
print(comparison)

print("\nSaved:")
print(summary_path)
print(comparison_path)