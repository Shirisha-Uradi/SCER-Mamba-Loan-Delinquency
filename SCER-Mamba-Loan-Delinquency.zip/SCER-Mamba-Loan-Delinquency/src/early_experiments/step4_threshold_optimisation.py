import pandas as pd
import numpy as np
import joblib
import os

from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)

# ============================================================
# STEP 4.4B - FINE-TUNE THRESHOLD
# ============================================================

validation_file = "Data/model_ready/validation_normalised.csv"
model_file = "output/models/baseline_logistic_model.pkl"
features_file = "Data/model_ready/model_features.pkl"

output_folder = "output/models"

os.makedirs(
    output_folder,
    exist_ok=True
)

print("========================================")
print("STEP 4.4B - FINE THRESHOLD OPTIMISATION")
print("========================================")


# ============================================================
# 1. LOAD VALIDATION DATA
# ============================================================

val_df = pd.read_csv(
    validation_file,
    low_memory=False
)

print(
    "\nValidation rows:",
    len(val_df)
)


# ============================================================
# 2. LOAD MODEL AND FEATURES
# ============================================================

model = joblib.load(
    model_file
)

features = joblib.load(
    features_file
)

print(
    "Number of features:",
    len(features)
)


# ============================================================
# 3. PREPARE VALIDATION DATA
# ============================================================

X_val = val_df[
    features
]

y_val = val_df[
    "target_risk_6m"
]


# ============================================================
# 4. GET MODEL PROBABILITIES
# ============================================================

probabilities = model.predict_proba(
    X_val
)[:, 1]


# ============================================================
# 5. TEST THRESHOLDS
#
# Previous search showed 0.95 was best.
# Now search more carefully between 0.90 and 0.995.
# ============================================================

thresholds = np.arange(
    0.90,
    1.00,
    0.005
)

results = []


for threshold in thresholds:

    predictions = (
        probabilities >= threshold
    ).astype(int)


    precision = precision_score(
        y_val,
        predictions,
        zero_division=0
    )


    recall = recall_score(
        y_val,
        predictions,
        zero_division=0
    )


    f1 = f1_score(
        y_val,
        predictions,
        zero_division=0
    )


    cm = confusion_matrix(
        y_val,
        predictions,
        labels=[0, 1]
    )


    tn, fp, fn, tp = cm.ravel()


    results.append({
        "Threshold": round(
            float(threshold),
            3
        ),

        "Precision": precision,

        "Recall": recall,

        "F1": f1,

        "True_Positive": tp,

        "False_Positive": fp,

        "False_Negative": fn,

        "True_Negative": tn
    })


# ============================================================
# 6. CREATE RESULTS TABLE
# ============================================================

results_df = pd.DataFrame(
    results
)


results_df = results_df.sort_values(
    "F1",
    ascending=False
).reset_index(
    drop=True
)


# ============================================================
# 7. PRINT TOP 10 THRESHOLDS
# ============================================================

print("\n========================================")
print("TOP 10 THRESHOLDS BY F1")
print("========================================")

print(
    results_df.head(10).to_string(
        index=False
    )
)


# ============================================================
# 8. BEST THRESHOLD
# ============================================================

best_row = results_df.iloc[0]

best_threshold = float(
    best_row["Threshold"]
)


print("\n========================================")
print("BEST FINE-TUNED THRESHOLD")
print("========================================")

print(
    "Threshold:",
    best_threshold
)

print(
    "Precision:",
    round(
        best_row["Precision"],
        4
    )
)

print(
    "Recall:",
    round(
        best_row["Recall"],
        4
    )
)

print(
    "F1:",
    round(
        best_row["F1"],
        4
    )
)

print(
    "True Positives:",
    int(
        best_row["True_Positive"]
    )
)

print(
    "False Positives:",
    int(
        best_row["False_Positive"]
    )
)

print(
    "False Negatives:",
    int(
        best_row["False_Negative"]
    )
)

print(
    "True Negatives:",
    int(
        best_row["True_Negative"]
    )
)


# ============================================================
# 9. SAVE ALL THRESHOLD RESULTS
# ============================================================

results_file = (
    f"{output_folder}/"
    "fine_threshold_comparison.csv"
)

results_df.to_csv(
    results_file,
    index=False
)


# ============================================================
# 10. SAVE BEST THRESHOLD
# ============================================================

threshold_file = (
    f"{output_folder}/"
    "best_logistic_threshold.pkl"
)

joblib.dump(
    best_threshold,
    threshold_file
)


# ============================================================
# 11. SAVE BEST THRESHOLD METRICS
# ============================================================

best_metrics = pd.DataFrame({
    "Metric": [
        "Threshold",
        "Precision",
        "Recall",
        "F1",
        "True_Positive",
        "False_Positive",
        "False_Negative",
        "True_Negative"
    ],

    "Value": [
        best_threshold,
        best_row["Precision"],
        best_row["Recall"],
        best_row["F1"],
        best_row["True_Positive"],
        best_row["False_Positive"],
        best_row["False_Negative"],
        best_row["True_Negative"]
    ]
})


best_metrics.to_csv(
    f"{output_folder}/"
    "best_logistic_threshold_metrics.csv",
    index=False
)


# ============================================================
# 12. COMPLETE
# ============================================================

print("\n========================================")
print("STEP 4.4B COMPLETED")
print("========================================")

print(
    "Threshold comparison saved:",
    results_file
)

print(
    "Best threshold saved:",
    threshold_file
)

print(
    "Best threshold metrics saved:",
    f"{output_folder}/"
    "best_logistic_threshold_metrics.csv"
)