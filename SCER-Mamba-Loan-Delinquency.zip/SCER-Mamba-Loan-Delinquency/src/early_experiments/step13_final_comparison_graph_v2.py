import os
import pandas as pd
import matplotlib.pyplot as plt

input_path = r"output/final_results_v2/j18_j24_heldout_test_results.csv"
output_path = r"output/final_results_v2/j18_j24_final_comparison.png"

df = pd.read_csv(input_path)

# Convert to percentages
metrics = [
    "Precision",
    "Recall",
    "F1",
    "ROC_AUC",
    "PR_AUC"
]

plot_df = df.copy()

for metric in metrics:
    plot_df[metric] = plot_df[metric] * 100

plot_df["Label"] = (
    plot_df["Cohort"]
    + " "
    + plot_df["Model"]
)

ax = plot_df.set_index("Label")[metrics].plot(
    kind="bar",
    figsize=(12, 7)
)

plt.title(
    "Held-Out Test Performance: SCER-Mamba vs LSTM"
)

plt.ylabel("Score (%)")
plt.xlabel("Model / Cohort")

plt.xticks(
    rotation=20,
    ha="right"
)

plt.ylim(0, 100)

plt.legend(
    title="Metric"
)

plt.tight_layout()

plt.savefig(
    output_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Graph saved:")
print(output_path)