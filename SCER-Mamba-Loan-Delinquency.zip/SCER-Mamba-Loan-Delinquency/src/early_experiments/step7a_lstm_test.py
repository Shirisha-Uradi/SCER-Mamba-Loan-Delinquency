import numpy as np
import torch
import torch.nn as nn
import joblib

from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix
)


# =========================================================
# PATHS
# =========================================================

DATA_DIR = "Data/sequential_model_ready"
MODEL_PATH = "output/sequential_models/best_lstm_model.pt"
THRESHOLD_PATH = "output/sequential_models/best_lstm_threshold.pkl"


# =========================================================
# LSTM ARCHITECTURE
# Matches saved model:
# temporal features = 7
# hidden size = 32
# static features = 12
# =========================================================

class LSTMRiskModel(nn.Module):

    def __init__(self):
        super().__init__()

        self.lstm = nn.LSTM(
            input_size=7,
            hidden_size=32,
            num_layers=1,
            batch_first=True
        )

        self.static_encoder = nn.Sequential(
            nn.Linear(12, 32),
            nn.ReLU()
        )

        self.classifier = nn.Sequential(
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Dropout(0.20),
            nn.Linear(32, 1)
        )

    def forward(self, sequence, static):

        lstm_output, _ = self.lstm(sequence)

        # Final month representation
        temporal_embedding = lstm_output[:, -1, :]

        static_embedding = self.static_encoder(static)

        combined = torch.cat(
            [temporal_embedding, static_embedding],
            dim=1
        )

        logits = self.classifier(combined).squeeze(-1)

        return logits


# =========================================================
# LOAD TEST DATA
# =========================================================

print("Loading sequential test data...")

X_sequence_test = np.load(
    f"{DATA_DIR}/X_sequence_test.npy"
)

X_static_test = np.load(
    f"{DATA_DIR}/X_static_test.npy"
)

y_test = np.load(
    f"{DATA_DIR}/y_test.npy"
)

print("Sequence test shape:", X_sequence_test.shape)
print("Static test shape:", X_static_test.shape)
print("Target test shape:", y_test.shape)


# =========================================================
# LOAD MODEL
# =========================================================

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("Device:", device)

model = LSTMRiskModel().to(device)

state_dict = torch.load(
    MODEL_PATH,
    map_location=device
)

model.load_state_dict(state_dict)

model.eval()

print("LSTM model loaded successfully")


# =========================================================
# LOAD VALIDATION-SELECTED THRESHOLD
# =========================================================

threshold = joblib.load(
    THRESHOLD_PATH
)

print("Saved threshold:", threshold)


# =========================================================
# TEST PREDICTIONS
# =========================================================

batch_size = 1024

probabilities = []

with torch.no_grad():

    for start in range(
        0,
        len(X_sequence_test),
        batch_size
    ):

        end = start + batch_size

        sequence_batch = torch.tensor(
            X_sequence_test[start:end],
            dtype=torch.float32,
            device=device
        )

        static_batch = torch.tensor(
            X_static_test[start:end],
            dtype=torch.float32,
            device=device
        )

        logits = model(
            sequence_batch,
            static_batch
        )

        probs = torch.sigmoid(logits)

        probabilities.extend(
            probs.cpu().numpy()
        )


probabilities = np.asarray(probabilities)

predictions = (
    probabilities >= threshold
).astype(int)


# =========================================================
# METRICS
# =========================================================

precision = precision_score(
    y_test,
    predictions,
    zero_division=0
)

recall = recall_score(
    y_test,
    predictions,
    zero_division=0
)

f1 = f1_score(
    y_test,
    predictions,
    zero_division=0
)

roc_auc = roc_auc_score(
    y_test,
    probabilities
)

pr_auc = average_precision_score(
    y_test,
    probabilities
)

tn, fp, fn, tp = confusion_matrix(
    y_test,
    predictions
).ravel()


# =========================================================
# RESULTS
# =========================================================

print("\n========================================")
print("FINAL LSTM TEST RESULTS")
print("========================================")

print(f"Threshold : {threshold:.2f}")
print(f"Precision : {precision:.4f}")
print(f"Recall    : {recall:.4f}")
print(f"F1 Score  : {f1:.4f}")
print(f"ROC-AUC   : {roc_auc:.4f}")
print(f"PR-AUC    : {pr_auc:.4f}")

print("\nConfusion Matrix")
print("TP:", tp)
print("FP:", fp)
print("FN:", fn)
print("TN:", tn)


# =========================================================
# SAVE FINAL TEST RESULTS
# =========================================================

results = {
    "threshold": float(threshold),
    "precision": float(precision),
    "recall": float(recall),
    "f1": float(f1),
    "roc_auc": float(roc_auc),
    "pr_auc": float(pr_auc),
    "TP": int(tp),
    "FP": int(fp),
    "FN": int(fn),
    "TN": int(tn)
}

joblib.dump(
    results,
    "output/sequential_models/lstm_test_metrics.pkl"
)

print("\nLSTM test metrics saved.")