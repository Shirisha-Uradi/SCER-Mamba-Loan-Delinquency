import pandas as pd
import matplotlib.pyplot as plt
import os

os.makedirs("output/final_results", exist_ok=True)

# Load latest complete results
df = pd.read_csv(
    "output/final_results/updated_complete_model_results.csv"
)

# Select the main models for a readable graph
selected_models = [
    "LSTM Baseline",
    "SCER-Mamba V2",
    "Focal Loss Only",
    "Experiment C - No Gate",
    "Experiment D - No Static Conditioning",
    "Experiment E - No Conditioning + No Gate",
    "Final Experiment D - 3 Seed Mean"
]

plot_df = df[
    df["Model"].isin(selected_models)
].copy()

metrics = [
    "Precision",
    "Recall",
    "F1",
    "PR_AUC"
]

plot_df = plot_df.set_index("Model")[metrics]

ax = plot_df.plot(
    kind="bar",
    figsize=(13, 7)
)

plt.title(
    "Updated SCER-Mamba Model Performance Comparison"
)

plt.ylabel("Score")
plt.xlabel("Model")

plt.ylim(0, 0.45)

plt.xticks(
    rotation=25,
    ha="right"
)

plt.legend(
    title="Metric"
)

plt.tight_layout()

output_path = (
    "output/final_results/"
    "updated_scer_mamba_model_comparison.png"
)

plt.savefig(
    output_path,
    dpi=300,
    bbox_inches="tight"
)

plt.show()

print("\nSaved:")
print(output_path)