import os
import pandas as pd

OUTPUT = r"output/final_results_v2"
os.makedirs(OUTPUT, exist_ok=True)

# ============================================================
# HELD-OUT TEST RESULTS
# ============================================================

test_results = pd.DataFrame([
    {
        "Cohort": "J18",
        "History_Months": 18,
        "Model": "SCER-Mamba",
        "Accuracy": 0.9844467600632936,
        "Precision": 0.34971098265895956,
        "Recall": 0.40468227424749165,
        "F1": 0.3751937984496124,
        "ROC_AUC": 0.8862466877722973,
        "PR_AUC": 0.2914668087272648,
        "Threshold": 0.40809500217437744
    },
    {
        "Cohort": "J18",
        "History_Months": 18,
        "Model": "LSTM",
        "Accuracy": 0.9862220678476323,
        "Precision": 0.39568345323741005,
        "Recall": 0.36789297658862874,
        "F1": 0.38128249566724437,
        "ROC_AUC": 0.8902296530106864,
        "PR_AUC": 0.30754357044312336,
        "Threshold": 0.4187439978122711
    },
    {
        "Cohort": "J24",
        "History_Months": 24,
        "Model": "SCER-Mamba",
        "Accuracy": 0.9853013228809407,
        "Precision": 0.3648293963254593,
        "Recall": 0.5408560311284046,
        "F1": 0.43573667711598746,
        "ROC_AUC": 0.9174984887760008,
        "PR_AUC": 0.3260134026282937,
        "Threshold": 0.3784582018852234
    },
    {
        "Cohort": "J24",
        "History_Months": 24,
        "Model": "LSTM",
        "Accuracy": 0.9862404050302139,
        "Precision": 0.3918918918918919,
        "Recall": 0.5642023346303502,
        "F1": 0.4625199362041467,
        "ROC_AUC": 0.919801810899919,
        "PR_AUC": 0.3681604203922252,
        "Threshold": 0.3823421895503998
    }
])

test_path = os.path.join(
    OUTPUT,
    "j18_j24_heldout_test_results.csv"
)

test_results.to_csv(
    test_path,
    index=False
)

# ============================================================
# VALIDATION RESULTS
# ============================================================

validation_results = pd.DataFrame([
    {
        "Cohort": "J18",
        "Model": "SCER-Mamba",
        "PR_AUC": 0.3176507618423367,
        "ROC_AUC": 0.885123220355007,
        "F1": 0.4058441557941986
    },
    {
        "Cohort": "J18",
        "Model": "LSTM",
        "PR_AUC": 0.29788470666183336,
        "ROC_AUC": 0.8885632231338048,
        "F1": 0.40574506278689565
    },
    {
        "Cohort": "J24",
        "Model": "SCER-Mamba",
        "PR_AUC": 0.29589391918814717,
        "ROC_AUC": 0.9077882825350673,
        "F1": 0.40397350988488495
    },
    {
        "Cohort": "J24",
        "Model": "LSTM",
        "PR_AUC": 0.315214122767998,
        "ROC_AUC": 0.9103398226991063,
        "F1": 0.4101694914762534
    }
])

validation_path = os.path.join(
    OUTPUT,
    "j18_j24_validation_results.csv"
)

validation_results.to_csv(
    validation_path,
    index=False
)

# ============================================================
# SIMPLE SUMMARY
# ============================================================

summary_path = os.path.join(
    OUTPUT,
    "results_summary_v2.txt"
)

with open(summary_path, "w") as f:

    f.write("RadarSeq / SCER-Mamba Results Summary V2\n")
    f.write("=" * 50 + "\n\n")

    f.write("J18 HELD-OUT TEST\n")
    f.write(
        "SCER-Mamba: PR-AUC 0.2915, ROC-AUC 0.8862, "
        "F1 0.3752, Recall 0.4047\n"
    )
    f.write(
        "LSTM:       PR-AUC 0.3075, ROC-AUC 0.8902, "
        "F1 0.3813, Recall 0.3679\n\n"
    )

    f.write("J24 HELD-OUT TEST\n")
    f.write(
        "SCER-Mamba: PR-AUC 0.3260, ROC-AUC 0.9175, "
        "F1 0.4357, Recall 0.5409\n"
    )
    f.write(
        "LSTM:       PR-AUC 0.3682, ROC-AUC 0.9198, "
        "F1 0.4625, Recall 0.5642\n\n"
    )

    f.write(
        "Experiment K reproducibility results pending.\n"
    )

print("\n======================================")
print("FINAL RESULTS V2 SAVED")
print("======================================")

print(test_path)
print(validation_path)
print(summary_path)

print("\nHELD-OUT TEST RESULTS")
print(test_results)