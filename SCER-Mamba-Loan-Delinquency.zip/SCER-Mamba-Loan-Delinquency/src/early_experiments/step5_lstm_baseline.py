import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)
import joblib
import os

# ============================================================
# STEP 5.3 - LSTM + STATIC BASELINE
# ============================================================

data_folder = "Data/sequential_model_ready"
output_folder = "output/sequential_models"

os.makedirs(output_folder, exist_ok=True)

print("========================================")
print("STEP 5.3 - LSTM SEQUENTIAL BASELINE")
print("========================================")

# CPU / GPU
device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("\nDevice:", device)


# ============================================================
# 1. LOAD DATA
# ============================================================

X_seq_train = np.load(
    f"{data_folder}/X_sequence_train.npy"
)

X_seq_val = np.load(
    f"{data_folder}/X_sequence_val.npy"
)

X_static_train = np.load(
    f"{data_folder}/X_static_train.npy"
)

X_static_val = np.load(
    f"{data_folder}/X_static_val.npy"
)

y_train = np.load(
    f"{data_folder}/y_train.npy"
)

y_val = np.load(
    f"{data_folder}/y_val.npy"
)

print("\nTraining sequence:", X_seq_train.shape)
print("Validation sequence:", X_seq_val.shape)
print("Training static:", X_static_train.shape)

print("\nTraining target:")
print(
    "Non-risky:",
    int((y_train == 0).sum())
)

print(
    "Risky:",
    int((y_train == 1).sum())
)


# ============================================================
# 2. CONVERT TO TORCH TENSORS
# ============================================================

train_dataset = TensorDataset(
    torch.tensor(
        X_seq_train,
        dtype=torch.float32
    ),
    torch.tensor(
        X_static_train,
        dtype=torch.float32
    ),
    torch.tensor(
        y_train,
        dtype=torch.float32
    )
)

val_dataset = TensorDataset(
    torch.tensor(
        X_seq_val,
        dtype=torch.float32
    ),
    torch.tensor(
        X_static_val,
        dtype=torch.float32
    ),
    torch.tensor(
        y_val,
        dtype=torch.float32
    )
)


# ============================================================
# 3. DATA LOADERS
# ============================================================

batch_size = 1024

train_loader = DataLoader(
    train_dataset,
    batch_size=batch_size,
    shuffle=True
)

val_loader = DataLoader(
    val_dataset,
    batch_size=batch_size,
    shuffle=False
)


# ============================================================
# 4. MODEL
# ============================================================

class LSTMStaticModel(nn.Module):

    def __init__(
        self,
        temporal_features,
        static_features
    ):
        super().__init__()

        # Temporal encoder
        self.lstm = nn.LSTM(
    input_size=temporal_features,
    hidden_size=32,
    num_layers=1,
    batch_first=True
)

        # Static encoder
        self.static_encoder = nn.Sequential(
            nn.Linear(
                static_features,
                32
            ),
            nn.ReLU(),
            nn.Dropout(0.2)
        )

        # Fusion layer
        self.classifier = nn.Sequential(
            nn.Linear(
                32 + 32,
                32
            ),
            nn.ReLU(),
            nn.Dropout(0.3),

            nn.Linear(
                32,
                1
            )
        )


    def forward(
        self,
        sequence,
        static
    ):

        lstm_output, _ = self.lstm(
            sequence
        )

        # Last time-step representation
        temporal_embedding = (
            lstm_output[:, -1, :]
        )

        static_embedding = (
            self.static_encoder(
                static
            )
        )

        combined = torch.cat(
            [
                temporal_embedding,
                static_embedding
            ],
            dim=1
        )

        output = self.classifier(
            combined
        )

        return output.squeeze(1)


model = LSTMStaticModel(
    temporal_features=X_seq_train.shape[2],
    static_features=X_static_train.shape[1]
).to(device)

print("\nModel:")
print(model)


# ============================================================
# 5. CLASS IMBALANCE WEIGHT
# ============================================================

positive_count = (
    y_train == 1
).sum()

negative_count = (
    y_train == 0
).sum()

pos_weight_value = (
    negative_count /
    positive_count
)

print(
    "\nPositive class weight:",
    round(
        float(pos_weight_value),
        2
    )
)

pos_weight = torch.tensor(
    [pos_weight_value],
    dtype=torch.float32,
    device=device
)

criterion = nn.BCEWithLogitsLoss(
    pos_weight=pos_weight
)

optimizer = torch.optim.Adam(
    model.parameters(),
    lr=0.001
)


# ============================================================
# 6. TRAINING
# ============================================================

epochs = 3

best_pr_auc = -1
patience = 3
patience_counter = 0

best_model_file = (
    f"{output_folder}/best_lstm_model.pt"
)

for epoch in range(
    1,
    epochs + 1
):

    # ------------------------
    # TRAIN
    # ------------------------

    model.train()

    total_loss = 0

    for (
        sequence_batch,
        static_batch,
        target_batch
    ) in train_loader:

        sequence_batch = (
            sequence_batch.to(device)
        )

        static_batch = (
            static_batch.to(device)
        )

        target_batch = (
            target_batch.to(device)
        )

        optimizer.zero_grad()

        logits = model(
            sequence_batch,
            static_batch
        )

        loss = criterion(
            logits,
            target_batch
        )

        loss.backward()

        optimizer.step()

        total_loss += (
            loss.item()
            * len(target_batch)
        )


    train_loss = (
        total_loss /
        len(train_dataset)
    )


    # ------------------------
    # VALIDATION
    # ------------------------

    model.eval()

    val_probs = []
    val_targets = []

    with torch.no_grad():

        for (
            sequence_batch,
            static_batch,
            target_batch
        ) in val_loader:

            sequence_batch = (
                sequence_batch.to(device)
            )

            static_batch = (
                static_batch.to(device)
            )

            logits = model(
                sequence_batch,
                static_batch
            )

            probabilities = torch.sigmoid(
                logits
            )

            val_probs.extend(
                probabilities.cpu().numpy()
            )

            val_targets.extend(
                target_batch.numpy()
            )


    val_probs = np.array(
        val_probs
    )

    val_targets = np.array(
        val_targets
    )


    roc_auc = roc_auc_score(
        val_targets,
        val_probs
    )

    pr_auc = average_precision_score(
        val_targets,
        val_probs
    )


    print(
        f"\nEpoch {epoch}/{epochs}"
    )

    print(
        "Train Loss:",
        round(
            train_loss,
            4
        )
    )

    print(
        "Validation ROC-AUC:",
        round(
            roc_auc,
            4
        )
    )

    print(
        "Validation PR-AUC:",
        round(
            pr_auc,
            4
        )
    )


    # ========================================================
    # EARLY STOPPING
    # ========================================================

    if pr_auc > best_pr_auc:

        best_pr_auc = pr_auc

        patience_counter = 0

        torch.save(
            model.state_dict(),
            best_model_file
        )

        print(
            "Best model updated."
        )

    else:

        patience_counter += 1

        if patience_counter >= patience:

            print(
                "\nEarly stopping triggered."
            )

            break


# ============================================================
# 7. LOAD BEST MODEL
# ============================================================

model.load_state_dict(
    torch.load(
        best_model_file,
        map_location=device
    )
)

model.eval()


# ============================================================
# 8. FINAL VALIDATION PROBABILITIES
# ============================================================

val_probs = []
val_targets = []

with torch.no_grad():

    for (
        sequence_batch,
        static_batch,
        target_batch
    ) in val_loader:

        sequence_batch = (
            sequence_batch.to(device)
        )

        static_batch = (
            static_batch.to(device)
        )

        logits = model(
            sequence_batch,
            static_batch
        )

        probabilities = torch.sigmoid(
            logits
        )

        val_probs.extend(
            probabilities.cpu().numpy()
        )

        val_targets.extend(
            target_batch.numpy()
        )


val_probs = np.array(
    val_probs
)

val_targets = np.array(
    val_targets
)


# ============================================================
# 9. FIND BEST VALIDATION THRESHOLD
# ============================================================

thresholds = np.arange(
    0.05,
    1.00,
    0.01
)

best_threshold = 0.5
best_f1 = -1
best_precision = 0
best_recall = 0

for threshold in thresholds:

    predictions = (
        val_probs >= threshold
    ).astype(int)

    f1 = f1_score(
        val_targets,
        predictions,
        zero_division=0
    )

    if f1 > best_f1:

        best_f1 = f1
        best_threshold = threshold

        best_precision = precision_score(
            val_targets,
            predictions,
            zero_division=0
        )

        best_recall = recall_score(
            val_targets,
            predictions,
            zero_division=0
        )


# ============================================================
# 10. FINAL VALIDATION METRICS
# ============================================================

final_predictions = (
    val_probs >= best_threshold
).astype(int)

roc_auc = roc_auc_score(
    val_targets,
    val_probs
)

pr_auc = average_precision_score(
    val_targets,
    val_probs
)

tn, fp, fn, tp = confusion_matrix(
    val_targets,
    final_predictions,
    labels=[0, 1]
).ravel()


print("\n========================================")
print("LSTM VALIDATION RESULTS")
print("========================================")

print(
    "Best threshold:",
    round(
        float(best_threshold),
        2
    )
)

print(
    "Precision:",
    round(
        best_precision,
        4
    )
)

print(
    "Recall:",
    round(
        best_recall,
        4
    )
)

print(
    "F1:",
    round(
        best_f1,
        4
    )
)

print(
    "ROC-AUC:",
    round(
        roc_auc,
        4
    )
)

print(
    "PR-AUC:",
    round(
        pr_auc,
        4
    )
)

print(
    "True Positives:",
    tp
)

print(
    "False Positives:",
    fp
)

print(
    "False Negatives:",
    fn
)

print(
    "True Negatives:",
    tn
)


# ============================================================
# 11. SAVE THRESHOLD + METRICS
# ============================================================

joblib.dump(
    float(best_threshold),
    f"{output_folder}/best_lstm_threshold.pkl"
)

metrics = {
    "threshold": float(
        best_threshold
    ),
    "precision": float(
        best_precision
    ),
    "recall": float(
        best_recall
    ),
    "f1": float(
        best_f1
    ),
    "roc_auc": float(
        roc_auc
    ),
    "pr_auc": float(
        pr_auc
    ),
    "true_positive": int(tp),
    "false_positive": int(fp),
    "false_negative": int(fn),
    "true_negative": int(tn)
}

joblib.dump(
    metrics,
    f"{output_folder}/lstm_validation_metrics.pkl"
)


print("\n========================================")
print("STEP 5.3 COMPLETED")
print("========================================")

print(
    "Best model:",
    best_model_file
)

print(
    "Outputs saved in:",
    output_folder
)