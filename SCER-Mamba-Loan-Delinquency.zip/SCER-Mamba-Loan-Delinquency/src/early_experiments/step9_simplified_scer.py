import os
import joblib
import numpy as np
import torch
import torch.nn as nn

from torch.utils.data import TensorDataset, DataLoader

from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix
)


# ============================================================
# 1. PATHS
# ============================================================

DATA_DIR = "Data/sequential_model_ready"
OUTPUT_DIR = "output/simplified_scer"

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)

MODEL_PATH = (
    f"{OUTPUT_DIR}/best_simplified_scer.pt"
)

METRICS_PATH = (
    f"{OUTPUT_DIR}/simplified_scer_test_metrics.pkl"
)


# ============================================================
# 2. LOAD DATA
# ============================================================

print("Loading sequential data...")

X_seq_train = np.load(
    f"{DATA_DIR}/X_sequence_train.npy"
)

X_seq_val = np.load(
    f"{DATA_DIR}/X_sequence_val.npy"
)

X_seq_test = np.load(
    f"{DATA_DIR}/X_sequence_test.npy"
)

X_static_train = np.load(
    f"{DATA_DIR}/X_static_train.npy"
)

X_static_val = np.load(
    f"{DATA_DIR}/X_static_val.npy"
)

X_static_test = np.load(
    f"{DATA_DIR}/X_static_test.npy"
)

y_train = np.load(
    f"{DATA_DIR}/y_train.npy"
)

y_val = np.load(
    f"{DATA_DIR}/y_val.npy"
)

y_test = np.load(
    f"{DATA_DIR}/y_test.npy"
)


print("Train:", X_seq_train.shape)
print("Validation:", X_seq_val.shape)
print("Test:", X_seq_test.shape)


# ============================================================
# 3. DATA LOADERS
# ============================================================

train_dataset = TensorDataset(
    torch.tensor(
        X_seq_train,
        dtype=torch.float32
    ),
    torch.tensor(
        X_static_train,
        dtype=torch.float32
    ),
    torch.tensor(
        y_train,
        dtype=torch.float32
    )
)

val_dataset = TensorDataset(
    torch.tensor(
        X_seq_val,
        dtype=torch.float32
    ),
    torch.tensor(
        X_static_val,
        dtype=torch.float32
    ),
    torch.tensor(
        y_val,
        dtype=torch.float32
    )
)

test_dataset = TensorDataset(
    torch.tensor(
        X_seq_test,
        dtype=torch.float32
    ),
    torch.tensor(
        X_static_test,
        dtype=torch.float32
    ),
    torch.tensor(
        y_test,
        dtype=torch.float32
    )
)


train_loader = DataLoader(
    train_dataset,
    batch_size=1024,
    shuffle=True
)

val_loader = DataLoader(
    val_dataset,
    batch_size=1024,
    shuffle=False
)

test_loader = DataLoader(
    test_dataset,
    batch_size=1024,
    shuffle=False
)

print("DataLoaders created.")


# ============================================================
# 4. SIMPLIFIED SCER
#
# REMOVED:
# - Static conditioning
# - Adaptive gated fusion
#
# KEPT:
# - Static encoder
# - GRU temporal encoder
# - Risk-event attention
# - Simple concatenation
# ============================================================

class SimplifiedSCER(nn.Module):

    def __init__(
        self,
        temporal_features=7,
        static_features=12,
        hidden_dim=32
    ):

        super().__init__()


        # ====================================================
        # STATIC ENCODER
        # ====================================================

        self.static_encoder = nn.Sequential(

            nn.Linear(
                static_features,
                32
            ),

            nn.ReLU(),

            nn.Dropout(0.2),

            nn.Linear(
                32,
                hidden_dim
            ),

            nn.ReLU()
        )


        # ====================================================
        # TEMPORAL ENCODER
        #
        # No static conditioning.
        # Raw prepared sequence enters GRU directly.
        # ====================================================

        self.temporal_encoder = nn.GRU(

            input_size=temporal_features,

            hidden_size=hidden_dim,

            num_layers=1,

            batch_first=True
        )


        # ====================================================
        # RISK-EVENT ATTENTION
        # ====================================================

        self.temporal_attention = nn.Linear(
            hidden_dim,
            hidden_dim
        )

        self.risk_projection = nn.Linear(
            1,
            hidden_dim
        )

        self.attention_score = nn.Linear(
            hidden_dim,
            1
        )


        # ====================================================
        # SIMPLE FUSION CLASSIFIER
        #
        # temporal context + static embedding
        # ====================================================

        self.classifier = nn.Sequential(

            nn.Linear(
                hidden_dim * 2,
                32
            ),

            nn.ReLU(),

            nn.Dropout(0.2),

            nn.Linear(
                32,
                1
            )
        )


    def forward(
        self,
        sequence,
        static
    ):


        # ====================================================
        # 1. STATIC REPRESENTATION
        # ====================================================

        static_embedding = self.static_encoder(
            static
        )


        # ====================================================
        # 2. TEMPORAL ENCODER
        #
        # No gamma/beta conditioning.
        # ====================================================

        temporal_output, _ = (
            self.temporal_encoder(
                sequence
            )
        )


        # ====================================================
        # 3. RISK-EVENT SIGNAL
        #
        # Feature positions:
        #
        # 4 = 30+ delinquent
        # 5 = 60+ delinquent
        # 6 = 90+ delinquent
        # ====================================================

        risk_event_signal = (

            sequence[:, :, 4]

            + sequence[:, :, 5]

            + sequence[:, :, 6]

        ).unsqueeze(-1)


        # ====================================================
        # 4. RISK-EVENT ATTENTION
        # ====================================================

        temporal_attention = (
            self.temporal_attention(
                temporal_output
            )
        )

        risk_attention = (
            self.risk_projection(
                risk_event_signal
            )
        )

        attention_energy = torch.tanh(

            temporal_attention
            + risk_attention

        )

        attention_logits = (
            self.attention_score(
                attention_energy
            )
            .squeeze(-1)
        )

        attention_weights = torch.softmax(
            attention_logits,
            dim=1
        )


        # Weighted temporal representation

        temporal_context = torch.sum(

            temporal_output

            * attention_weights.unsqueeze(-1),

            dim=1
        )


        # ====================================================
        # 5. SIMPLE FUSION
        #
        # No adaptive gate.
        # ====================================================

        fused_representation = torch.cat(

            [
                temporal_context,
                static_embedding
            ],

            dim=1
        )


        # ====================================================
        # 6. PREDICTION
        # ====================================================

        logits = self.classifier(
            fused_representation
        ).squeeze(1)


        return (
            logits,
            attention_weights
        )


# ============================================================
# 5. DEVICE
# ============================================================

device = torch.device(
    "cuda"
    if torch.cuda.is_available()
    else "cpu"
)

print("Device:", device)


# ============================================================
# 6. INITIALISE MODEL
# ============================================================

model = SimplifiedSCER(
    temporal_features=7,
    static_features=12,
    hidden_dim=32
).to(device)


# ============================================================
# 7. CLASS IMBALANCE
# ============================================================

positive = float(
    y_train.sum()
)

negative = float(
    (y_train == 0).sum()
)

pos_weight_value = (
    negative / positive
)

print(
    "Positive class weight:",
    pos_weight_value
)

pos_weight = torch.tensor(
    pos_weight_value,
    dtype=torch.float32,
    device=device
)

criterion = nn.BCEWithLogitsLoss(
    pos_weight=pos_weight
)


# ============================================================
# 8. OPTIMIZER
# ============================================================

optimizer = torch.optim.Adam(
    model.parameters(),
    lr=0.001,
    weight_decay=1e-5
)


# ============================================================
# 9. TRAINING
# ============================================================

EPOCHS = 3

best_pr_auc = -1


for epoch in range(EPOCHS):


    # ========================================================
    # TRAIN
    # ========================================================

    model.train()

    total_loss = 0.0


    for (
        sequences,
        static,
        targets
    ) in train_loader:


        sequences = sequences.to(device)
        static = static.to(device)
        targets = targets.to(device)


        optimizer.zero_grad()


        logits, _ = model(
            sequences,
            static
        )


        loss = criterion(
            logits,
            targets
        )


        loss.backward()


        torch.nn.utils.clip_grad_norm_(
            model.parameters(),
            1.0
        )


        optimizer.step()


        total_loss += loss.item()


    train_loss = (
        total_loss
        / len(train_loader)
    )


    # ========================================================
    # VALIDATION
    # ========================================================

    model.eval()

    val_probs = []
    val_targets = []


    with torch.no_grad():

        for (
            sequences,
            static,
            targets
        ) in val_loader:


            sequences = sequences.to(device)
            static = static.to(device)


            logits, _ = model(
                sequences,
                static
            )


            probs = torch.sigmoid(
                logits
            )


            val_probs.extend(
                probs.cpu().numpy()
            )


            val_targets.extend(
                targets.numpy()
            )


    val_probs = np.asarray(
        val_probs
    )

    val_targets = np.asarray(
        val_targets
    )


    roc_auc = roc_auc_score(
        val_targets,
        val_probs
    )

    pr_auc = average_precision_score(
        val_targets,
        val_probs
    )


    print(
        f"\nEpoch {epoch + 1}/{EPOCHS}"
    )

    print(
        f"Train Loss : {train_loss:.4f}"
    )

    print(
        f"ROC-AUC    : {roc_auc:.4f}"
    )

    print(
        f"PR-AUC     : {pr_auc:.4f}"
    )


    # ========================================================
    # SAVE BEST MODEL
    # ========================================================

    if pr_auc > best_pr_auc:

        best_pr_auc = pr_auc


        torch.save(
            model.state_dict(),
            MODEL_PATH
        )


        print(
            "Best simplified SCER model saved."
        )


# ============================================================
# 10. LOAD BEST MODEL
# ============================================================

model.load_state_dict(
    torch.load(
        MODEL_PATH,
        map_location=device
    )
)

model.eval()


print(
    "\nBest validation PR-AUC:",
    best_pr_auc
)


# ============================================================
# 11. VALIDATION PREDICTIONS
# ============================================================

val_probs = []
val_targets = []


with torch.no_grad():

    for (
        sequences,
        static,
        targets
    ) in val_loader:


        sequences = sequences.to(device)
        static = static.to(device)


        logits, _ = model(
            sequences,
            static
        )


        probs = torch.sigmoid(
            logits
        )


        val_probs.extend(
            probs.cpu().numpy()
        )


        val_targets.extend(
            targets.numpy()
        )


val_probs = np.asarray(
    val_probs
)

val_targets = np.asarray(
    val_targets
)


# ============================================================
# 12. VALIDATION THRESHOLD OPTIMISATION
# ============================================================

best_threshold = 0.50
best_f1 = -1


for threshold in np.arange(
    0.05,
    1.00,
    0.01
):


    predictions = (
        val_probs
        >= threshold
    ).astype(int)


    score = f1_score(
        val_targets,
        predictions,
        zero_division=0
    )


    if score > best_f1:

        best_f1 = score
        best_threshold = threshold


print(
    "\nBest validation threshold:",
    round(
        best_threshold,
        2
    )
)

print(
    "Best validation F1:",
    round(
        best_f1,
        4
    )
)


# ============================================================
# 13. TEST PREDICTIONS
# ============================================================

test_probs = []
test_targets = []
test_attention = []


with torch.no_grad():

    for (
        sequences,
        static,
        targets
    ) in test_loader:


        sequences = sequences.to(device)
        static = static.to(device)


        logits, attention = model(
            sequences,
            static
        )


        probs = torch.sigmoid(
            logits
        )


        test_probs.extend(
            probs.cpu().numpy()
        )


        test_targets.extend(
            targets.numpy()
        )


        test_attention.append(
            attention.cpu().numpy()
        )


test_probs = np.asarray(
    test_probs
)

test_targets = np.asarray(
    test_targets
)

test_attention = np.concatenate(
    test_attention,
    axis=0
)


test_predictions = (
    test_probs
    >= best_threshold
).astype(int)


# ============================================================
# 14. FINAL TEST METRICS
# ============================================================

precision = precision_score(
    test_targets,
    test_predictions,
    zero_division=0
)

recall = recall_score(
    test_targets,
    test_predictions,
    zero_division=0
)

f1 = f1_score(
    test_targets,
    test_predictions,
    zero_division=0
)

roc_auc = roc_auc_score(
    test_targets,
    test_probs
)

pr_auc = average_precision_score(
    test_targets,
    test_probs
)

tn, fp, fn, tp = confusion_matrix(
    test_targets,
    test_predictions
).ravel()


# ============================================================
# 15. PRINT FINAL RESULTS
# ============================================================

print(
    "\n========================================"
)

print(
    "STEP 9 - SIMPLIFIED SCER"
)

print(
    "========================================"
)

print(
    f"Threshold : {best_threshold:.2f}"
)

print(
    f"Precision : {precision:.4f}"
)

print(
    f"Recall    : {recall:.4f}"
)

print(
    f"F1 Score  : {f1:.4f}"
)

print(
    f"ROC-AUC   : {roc_auc:.4f}"
)

print(
    f"PR-AUC    : {pr_auc:.4f}"
)


print(
    "\nConfusion Matrix"
)

print("TP:", tp)
print("FP:", fp)
print("FN:", fn)
print("TN:", tn)


# ============================================================
# 16. ATTENTION ANALYSIS
# ============================================================

mean_attention = (
    test_attention.mean(
        axis=0
    )
)


print(
    "\nMean attention by month:"
)

for month, value in enumerate(
    mean_attention,
    start=1
):

    print(
        f"Month {month}: "
        f"{value:.4f}"
    )


# ============================================================
# 17. SAVE OUTPUTS
# ============================================================

results = {

    "model":
        "Simplified SCER",

    "threshold":
        float(best_threshold),

    "precision":
        float(precision),

    "recall":
        float(recall),

    "f1":
        float(f1),

    "roc_auc":
        float(roc_auc),

    "pr_auc":
        float(pr_auc),

    "TP":
        int(tp),

    "FP":
        int(fp),

    "FN":
        int(fn),

    "TN":
        int(tn)
}


joblib.dump(
    results,
    METRICS_PATH
)


np.save(
    f"{OUTPUT_DIR}/test_attention_weights.npy",
    test_attention
)


np.save(
    f"{OUTPUT_DIR}/mean_attention_by_month.npy",
    mean_attention
)


print(
    "\nSaved:",
    METRICS_PATH
)

print(
    "\nSTEP 9 COMPLETED"
)