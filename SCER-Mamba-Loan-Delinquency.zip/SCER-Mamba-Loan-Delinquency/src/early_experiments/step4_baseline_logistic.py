import pandas as pd
import numpy as np
import os
import joblib

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
    classification_report
)

# ============================================================
# STEP 4.3 - BASELINE LOGISTIC REGRESSION
# ============================================================

train_file = "Data/model_ready/train_normalised.csv"
val_file = "Data/model_ready/validation_normalised.csv"

features_file = "Data/model_ready/model_features.pkl"

output_folder = "output/models"
os.makedirs(output_folder, exist_ok=True)

print("========================================")
print("STEP 4.3 - BASELINE LOGISTIC REGRESSION")
print("========================================")


# ============================================================
# 1. LOAD DATA
# ============================================================

train_df = pd.read_csv(
    train_file,
    low_memory=False
)

val_df = pd.read_csv(
    val_file,
    low_memory=False
)

features = joblib.load(
    features_file
)

print("\nTraining rows:", len(train_df))
print("Validation rows:", len(val_df))
print("Number of features:", len(features))


# ============================================================
# 2. PREPARE X AND y
# ============================================================

X_train = train_df[features]
y_train = train_df["target_risk_6m"]

X_val = val_df[features]
y_val = val_df["target_risk_6m"]


print("\nTraining target distribution:")
print(
    y_train.value_counts().sort_index()
)

print("\nValidation target distribution:")
print(
    y_val.value_counts().sort_index()
)


# ============================================================
# 3. TRAIN BASELINE MODEL
# ============================================================

print("\nTraining Logistic Regression...")

model = LogisticRegression(
    class_weight="balanced",
    max_iter=1000,
    random_state=42
)

model.fit(
    X_train,
    y_train
)

print("Model training completed.")


# ============================================================
# 4. VALIDATION PREDICTIONS
# ============================================================

val_probability = model.predict_proba(
    X_val
)[:, 1]

val_prediction = (
    val_probability >= 0.5
).astype(int)


# ============================================================
# 5. CALCULATE METRICS
# ============================================================

accuracy = accuracy_score(
    y_val,
    val_prediction
)

precision = precision_score(
    y_val,
    val_prediction,
    zero_division=0
)

recall = recall_score(
    y_val,
    val_prediction,
    zero_division=0
)

f1 = f1_score(
    y_val,
    val_prediction,
    zero_division=0
)

roc_auc = roc_auc_score(
    y_val,
    val_probability
)

pr_auc = average_precision_score(
    y_val,
    val_probability
)


print("\n========================================")
print("VALIDATION METRICS")
print("========================================")

print("Accuracy:", round(accuracy, 4))
print("Precision:", round(precision, 4))
print("Recall:", round(recall, 4))
print("F1-score:", round(f1, 4))
print("ROC-AUC:", round(roc_auc, 4))
print("PR-AUC:", round(pr_auc, 4))


# ============================================================
# 6. CONFUSION MATRIX
# ============================================================

cm = confusion_matrix(
    y_val,
    val_prediction
)

tn, fp, fn, tp = cm.ravel()

print("\n========================================")
print("CONFUSION MATRIX")
print("========================================")

print("True Negatives:", tn)
print("False Positives:", fp)
print("False Negatives:", fn)
print("True Positives:", tp)


# ============================================================
# 7. CLASSIFICATION REPORT
# ============================================================

print("\n========================================")
print("CLASSIFICATION REPORT")
print("========================================")

print(
    classification_report(
        y_val,
        val_prediction,
        digits=4,
        zero_division=0
    )
)


# ============================================================
# 8. SAVE VALIDATION RESULTS
# ============================================================

results = pd.DataFrame({
    "Metric": [
        "Accuracy",
        "Precision",
        "Recall",
        "F1",
        "ROC_AUC",
        "PR_AUC"
    ],

    "Value": [
        accuracy,
        precision,
        recall,
        f1,
        roc_auc,
        pr_auc
    ]
})

results.to_csv(
    f"{output_folder}/logistic_validation_metrics.csv",
    index=False
)


confusion_df = pd.DataFrame(
    cm,
    index=[
        "Actual_Non_Risky",
        "Actual_Risky"
    ],
    columns=[
        "Predicted_Non_Risky",
        "Predicted_Risky"
    ]
)

confusion_df.to_csv(
    f"{output_folder}/logistic_confusion_matrix.csv"
)


# ============================================================
# 9. SAVE MODEL
# ============================================================

joblib.dump(
    model,
    f"{output_folder}/baseline_logistic_model.pkl"
)


print("\n========================================")
print("STEP 4.3 COMPLETED")
print("========================================")

print(
    "Model saved:",
    f"{output_folder}/baseline_logistic_model.pkl"
)

print(
    "Metrics saved:",
    f"{output_folder}/logistic_validation_metrics.csv"
)