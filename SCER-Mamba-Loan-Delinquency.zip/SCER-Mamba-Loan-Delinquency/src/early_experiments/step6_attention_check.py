import numpy as np

attention_file = "output/scer/validation_attention_weights.npy"
target_file = "Data/sequential_model_ready/y_val.npy"

attention = np.load(attention_file)
y = np.load(target_file)

print("========================================")
print("SCER ATTENTION SANITY CHECK")
print("========================================")

print("\nAttention shape:", attention.shape)
print("Target shape:", y.shape)

risky_attention = attention[y == 1]
non_risky_attention = attention[y == 0]

risky_mean = risky_attention.mean(axis=0)
non_risky_mean = non_risky_attention.mean(axis=0)

print("\nRISKY LOANS")
print("----------------------------------------")

for month, value in enumerate(risky_mean, start=1):
    print(f"Month {month}: {value:.4f}")

print("\nNON-RISKY LOANS")
print("----------------------------------------")

for month, value in enumerate(non_risky_mean, start=1):
    print(f"Month {month}: {value:.4f}")

print("\nAttention sums:")

print(
    "Risky:",
    round(float(risky_mean.sum()), 4)
)

print(
    "Non-risky:",
    round(float(non_risky_mean.sum()), 4)
)

print("\nDifference: Risky - Non-risky")
print("----------------------------------------")

difference = risky_mean - non_risky_mean

for month, value in enumerate(difference, start=1):
    print(f"Month {month}: {value:+.4f}")

print("\n========================================")
print("ATTENTION CHECK COMPLETED")
print("========================================")