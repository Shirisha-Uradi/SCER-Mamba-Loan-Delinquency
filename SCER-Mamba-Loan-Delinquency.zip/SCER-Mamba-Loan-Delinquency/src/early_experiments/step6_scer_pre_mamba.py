import os
import joblib
import numpy as np

import torch
import torch.nn as nn
from torch.utils.data import (
    TensorDataset,
    DataLoader
)

from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)


# ============================================================
# STEP 6.1 - SCER PRE-MAMBA PROTOTYPE
#
# Architecture:
#
# Static features
#      ↓
# Static MLP Encoder
#      ↓
# Static Conditioning
#
# 12-month sequence
#      ↓
# GRU Temporal Encoder
#      ↓
# Risk-Event Attention
#
# Static + Temporal
#      ↓
# Adaptive Gated Fusion
#      ↓
# 6-month risk probability
# ============================================================


data_folder = "Data/sequential_model_ready"
output_folder = "output/scer"

os.makedirs(
    output_folder,
    exist_ok=True
)

print("========================================")
print("STEP 6.1 - SCER PRE-MAMBA")
print("========================================")


# ============================================================
# 1. DEVICE
# ============================================================

device = torch.device(
    "cuda"
    if torch.cuda.is_available()
    else "cpu"
)

print("\nDevice:", device)


# ============================================================
# 2. LOAD DATA
# ============================================================

X_seq_train = np.load(
    f"{data_folder}/X_sequence_train.npy"
)

X_seq_val = np.load(
    f"{data_folder}/X_sequence_val.npy"
)

X_static_train = np.load(
    f"{data_folder}/X_static_train.npy"
)

X_static_val = np.load(
    f"{data_folder}/X_static_val.npy"
)

y_train = np.load(
    f"{data_folder}/y_train.npy"
)

y_val = np.load(
    f"{data_folder}/y_val.npy"
)


print("\nTraining sequence:")
print(X_seq_train.shape)

print("Validation sequence:")
print(X_seq_val.shape)

print("Training static:")
print(X_static_train.shape)

print("Validation static:")
print(X_static_val.shape)


# ============================================================
# 3. TARGET DISTRIBUTION
# ============================================================

train_negative = int(
    (y_train == 0).sum()
)

train_positive = int(
    (y_train == 1).sum()
)

print("\nTraining target:")

print(
    "Non-risky:",
    train_negative
)

print(
    "Risky:",
    train_positive
)


# ============================================================
# 4. DATASETS
# ============================================================

train_dataset = TensorDataset(

    torch.tensor(
        X_seq_train,
        dtype=torch.float32
    ),

    torch.tensor(
        X_static_train,
        dtype=torch.float32
    ),

    torch.tensor(
        y_train,
        dtype=torch.float32
    )
)


val_dataset = TensorDataset(

    torch.tensor(
        X_seq_val,
        dtype=torch.float32
    ),

    torch.tensor(
        X_static_val,
        dtype=torch.float32
    ),

    torch.tensor(
        y_val,
        dtype=torch.float32
    )
)


# ============================================================
# 5. DATA LOADERS
# ============================================================

batch_size = 1024

train_loader = DataLoader(
    train_dataset,
    batch_size=batch_size,
    shuffle=True
)

val_loader = DataLoader(
    val_dataset,
    batch_size=batch_size,
    shuffle=False
)


# ============================================================
# 6. SCER MODEL
# ============================================================

class SCERPreMamba(nn.Module):

    def __init__(
        self,
        temporal_features,
        static_features,
        hidden_dim=32
    ):

        super().__init__()

        self.temporal_features = (
            temporal_features
        )

        self.hidden_dim = (
            hidden_dim
        )


        # ====================================================
        # A. STATIC ENCODER
        # ====================================================

        self.static_encoder = nn.Sequential(

            nn.Linear(
                static_features,
                32
            ),

            nn.ReLU(),

            nn.Dropout(
                0.2
            ),

            nn.Linear(
                32,
                hidden_dim
            ),

            nn.ReLU()
        )


        # ====================================================
        # B. STATIC-CONDITIONING LAYER
        #
        # Produces gamma and beta values.
        #
        # Conditioned sequence:
        # x' = x * (1 + gamma) + beta
        # ====================================================

        self.condition_gamma = nn.Linear(
            hidden_dim,
            temporal_features
        )

        self.condition_beta = nn.Linear(
            hidden_dim,
            temporal_features
        )


        # ====================================================
        # C. TEMPORAL ENCODER
        #
        # GRU is used here as CPU-compatible placeholder.
        # This will later be replaced by Mamba.
        # ====================================================

        self.temporal_encoder = nn.GRU(

            input_size=temporal_features,

            hidden_size=hidden_dim,

            num_layers=1,

            batch_first=True
        )


        # ====================================================
        # D. RISK-EVENT ATTENTION
        #
        # Uses temporal hidden states + delinquency-event
        # information to identify important months.
        # ====================================================

        self.temporal_attention = nn.Linear(
            hidden_dim,
            hidden_dim
        )

        self.risk_projection = nn.Linear(
            1,
            hidden_dim
        )

        self.attention_score = nn.Linear(
            hidden_dim,
            1
        )


        # ====================================================
        # E. ADAPTIVE GATED FUSION
        #
        # Learns how much to rely on:
        #
        # - temporal behaviour
        # - static borrower information
        # ====================================================

        self.fusion_gate = nn.Linear(
            hidden_dim * 2,
            hidden_dim
        )


        # ====================================================
        # F. CLASSIFIER
        # ====================================================

        self.classifier = nn.Sequential(

            nn.Linear(
                hidden_dim,
                32
            ),

            nn.ReLU(),

            nn.Dropout(
                0.3
            ),

            nn.Linear(
                32,
                1
            )
        )


    # ========================================================
    # FORWARD PASS
    # ========================================================

    def forward(
        self,
        sequence,
        static
    ):


        # ----------------------------------------------------
        # 1. Static encoding
        # ----------------------------------------------------

        static_embedding = (
            self.static_encoder(
                static
            )
        )


        # ----------------------------------------------------
        # 2. Static conditioning
        # ----------------------------------------------------

        gamma = torch.tanh(
            self.condition_gamma(
                static_embedding
            )
        )

        beta = (
            self.condition_beta(
                static_embedding
            )
        )


        gamma = gamma.unsqueeze(
            1
        )

        beta = beta.unsqueeze(
            1
        )


        conditioned_sequence = (
            sequence
            * (
                1.0
                + gamma
            )
            + beta
        )


        # ----------------------------------------------------
        # 3. Temporal encoder
        # ----------------------------------------------------

        temporal_output, _ = (
            self.temporal_encoder(
                conditioned_sequence
            )
        )


        # ----------------------------------------------------
        # 4. Risk-event signal
        #
        # Temporal feature positions:
        #
        # 0 current_interest_rate
        # 1 current_actual_upb
        # 2 delinquency_status_numeric
        # 3 remaining_months_to_maturity
        # 4 is_30plus_delinquent
        # 5 is_60plus_delinquent
        # 6 is_90plus_delinquent
        # ----------------------------------------------------

        risk_event_signal = (

            sequence[:, :, 4]

            + sequence[:, :, 5]

            + sequence[:, :, 6]

        ).unsqueeze(
            -1
        )


        # ----------------------------------------------------
        # 5. Risk-event attention
        # ----------------------------------------------------

        temporal_attention = (
            self.temporal_attention(
                temporal_output
            )
        )

        risk_attention = (
            self.risk_projection(
                risk_event_signal
            )
        )


        attention_energy = torch.tanh(

            temporal_attention
            + risk_attention

        )


        attention_logits = (
            self.attention_score(
                attention_energy
            )
            .squeeze(-1)
        )


        attention_weights = torch.softmax(
            attention_logits,
            dim=1
        )


        temporal_context = torch.sum(

            temporal_output

            * attention_weights.unsqueeze(
                -1
            ),

            dim=1
        )


        # ----------------------------------------------------
        # 6. Adaptive gated fusion
        # ----------------------------------------------------

        fusion_input = torch.cat(
            [
                temporal_context,
                static_embedding
            ],
            dim=1
        )


        gate = torch.sigmoid(
            self.fusion_gate(
                fusion_input
            )
        )


        fused_representation = (

            gate
            * temporal_context

            +

            (
                1.0
                - gate
            )
            * static_embedding

        )


        # ----------------------------------------------------
        # 7. Prediction
        # ----------------------------------------------------

        logits = self.classifier(
            fused_representation
        ).squeeze(
            1
        )


        return (
            logits,
            attention_weights,
            gate
        )


# ============================================================
# 7. INITIALISE MODEL
# ============================================================

model = SCERPreMamba(

    temporal_features=(
        X_seq_train.shape[2]
    ),

    static_features=(
        X_static_train.shape[1]
    ),

    hidden_dim=32

).to(
    device
)


print("\nModel:")
print(model)


# ============================================================
# 8. CLASS IMBALANCE
# ============================================================

positive_weight_value = (

    train_negative
    /
    train_positive

)


print(
    "\nPositive class weight:",
    round(
        positive_weight_value,
        2
    )
)


positive_weight = torch.tensor(

    [
        positive_weight_value
    ],

    dtype=torch.float32,

    device=device
)


criterion = nn.BCEWithLogitsLoss(
    pos_weight=positive_weight
)


optimizer = torch.optim.Adam(

    model.parameters(),

    lr=0.001,

    weight_decay=1e-5
)


# ============================================================
# 9. TRAINING SETTINGS
# ============================================================

epochs = 3

best_pr_auc = -1

best_model_file = (
    f"{output_folder}/"
    "best_scer_pre_mamba.pt"
)


# ============================================================
# 10. TRAINING LOOP
# ============================================================

for epoch in range(
    1,
    epochs + 1
):


    # ========================================================
    # TRAIN
    # ========================================================

    model.train()

    running_loss = 0


    for (
        sequence_batch,
        static_batch,
        target_batch
    ) in train_loader:


        sequence_batch = (
            sequence_batch.to(
                device
            )
        )

        static_batch = (
            static_batch.to(
                device
            )
        )

        target_batch = (
            target_batch.to(
                device
            )
        )


        optimizer.zero_grad()


        logits, _, _ = model(

            sequence_batch,

            static_batch
        )


        loss = criterion(

            logits,

            target_batch
        )


        loss.backward()


        # Gradient clipping
        torch.nn.utils.clip_grad_norm_(
            model.parameters(),
            max_norm=5.0
        )


        optimizer.step()


        running_loss += (

            loss.item()

            * len(
                target_batch
            )

        )


    train_loss = (

        running_loss

        /

        len(
            train_dataset
        )

    )


    # ========================================================
    # VALIDATION
    # ========================================================

    model.eval()


    val_probabilities = []

    val_targets = []


    with torch.no_grad():


        for (
            sequence_batch,
            static_batch,
            target_batch
        ) in val_loader:


            sequence_batch = (
                sequence_batch.to(
                    device
                )
            )

            static_batch = (
                static_batch.to(
                    device
                )
            )


            logits, _, _ = model(

                sequence_batch,

                static_batch
            )


            probability = torch.sigmoid(
                logits
            )


            val_probabilities.extend(

                probability
                .cpu()
                .numpy()

            )


            val_targets.extend(

                target_batch
                .numpy()

            )


    val_probabilities = np.array(
        val_probabilities
    )


    val_targets = np.array(
        val_targets
    )


    roc_auc = roc_auc_score(

        val_targets,

        val_probabilities
    )


    pr_auc = average_precision_score(

        val_targets,

        val_probabilities
    )


    print(
        f"\nEpoch {epoch}/{epochs}"
    )


    print(
        "Train Loss:",
        round(
            train_loss,
            4
        )
    )


    print(
        "Validation ROC-AUC:",
        round(
            roc_auc,
            4
        )
    )


    print(
        "Validation PR-AUC:",
        round(
            pr_auc,
            4
        )
    )


    if pr_auc > best_pr_auc:


        best_pr_auc = (
            pr_auc
        )


        torch.save(

            model.state_dict(),

            best_model_file
        )


        print(
            "Best model updated."
        )


# ============================================================
# 11. LOAD BEST MODEL
# ============================================================

model.load_state_dict(

    torch.load(

        best_model_file,

        map_location=device
    )
)


model.eval()


# ============================================================
# 12. FINAL VALIDATION PREDICTIONS
# ============================================================

val_probabilities = []

val_targets = []

all_attention_weights = []


with torch.no_grad():


    for (
        sequence_batch,
        static_batch,
        target_batch
    ) in val_loader:


        sequence_batch = (
            sequence_batch.to(
                device
            )
        )

        static_batch = (
            static_batch.to(
                device
            )
        )


        (
            logits,
            attention_weights,
            _
        ) = model(

            sequence_batch,

            static_batch
        )


        probability = torch.sigmoid(
            logits
        )


        val_probabilities.extend(

            probability
            .cpu()
            .numpy()

        )


        val_targets.extend(

            target_batch
            .numpy()

        )


        all_attention_weights.append(

            attention_weights
            .cpu()
            .numpy()

        )


val_probabilities = np.array(
    val_probabilities
)


val_targets = np.array(
    val_targets
)


all_attention_weights = np.concatenate(

    all_attention_weights,

    axis=0
)


# ============================================================
# 13. THRESHOLD OPTIMISATION
# ============================================================

thresholds = np.arange(

    0.05,

    1.00,

    0.01
)


best_threshold = 0.50

best_f1 = -1

best_precision = 0

best_recall = 0


for threshold in thresholds:


    predictions = (

        val_probabilities
        >= threshold

    ).astype(
        int
    )


    current_f1 = f1_score(

        val_targets,

        predictions,

        zero_division=0
    )


    if current_f1 > best_f1:


        best_f1 = (
            current_f1
        )


        best_threshold = (
            threshold
        )


        best_precision = precision_score(

            val_targets,

            predictions,

            zero_division=0
        )


        best_recall = recall_score(

            val_targets,

            predictions,

            zero_division=0
        )


# ============================================================
# 14. FINAL METRICS
# ============================================================

final_predictions = (

    val_probabilities

    >= best_threshold

).astype(
    int
)


roc_auc = roc_auc_score(

    val_targets,

    val_probabilities
)


pr_auc = average_precision_score(

    val_targets,

    val_probabilities
)


tn, fp, fn, tp = confusion_matrix(

    val_targets,

    final_predictions,

    labels=[
        0,
        1
    ]

).ravel()


print("\n========================================")
print("SCER PRE-MAMBA VALIDATION RESULTS")
print("========================================")


print(
    "Best threshold:",
    round(
        float(
            best_threshold
        ),
        2
    )
)


print(
    "Precision:",
    round(
        best_precision,
        4
    )
)


print(
    "Recall:",
    round(
        best_recall,
        4
    )
)


print(
    "F1:",
    round(
        best_f1,
        4
    )
)


print(
    "ROC-AUC:",
    round(
        roc_auc,
        4
    )
)


print(
    "PR-AUC:",
    round(
        pr_auc,
        4
    )
)


print(
    "True Positives:",
    tp
)


print(
    "False Positives:",
    fp
)


print(
    "False Negatives:",
    fn
)


print(
    "True Negatives:",
    tn
)


# ============================================================
# 15. ATTENTION SUMMARY
# ============================================================

mean_attention = (
    all_attention_weights.mean(
        axis=0
    )
)


print("\n========================================")
print("AVERAGE ATTENTION BY LOAN MONTH")
print("========================================")


for month, attention in enumerate(
    mean_attention,
    start=1
):


    print(

        f"Month {month}: "
        f"{attention:.4f}"

    )


# ============================================================
# 16. SAVE OUTPUTS
# ============================================================

metrics = {

    "threshold":
        float(
            best_threshold
        ),

    "precision":
        float(
            best_precision
        ),

    "recall":
        float(
            best_recall
        ),

    "f1":
        float(
            best_f1
        ),

    "roc_auc":
        float(
            roc_auc
        ),

    "pr_auc":
        float(
            pr_auc
        ),

    "true_positive":
        int(
            tp
        ),

    "false_positive":
        int(
            fp
        ),

    "false_negative":
        int(
            fn
        ),

    "true_negative":
        int(
            tn
        )
}


joblib.dump(

    metrics,

    f"{output_folder}/"
    "scer_pre_mamba_metrics.pkl"
)


joblib.dump(

    float(
        best_threshold
    ),

    f"{output_folder}/"
    "best_scer_threshold.pkl"
)


np.save(

    f"{output_folder}/"
    "validation_attention_weights.npy",

    all_attention_weights
)


np.save(

    f"{output_folder}/"
    "mean_attention_by_month.npy",

    mean_attention
)


print("\n========================================")
print("STEP 6.1 COMPLETED")
print("========================================")


print(
    "Best model:",
    best_model_file
)


print(
    "Outputs saved in:",
    output_folder
)