import pandas as pd
import matplotlib.pyplot as plt
import os

os.makedirs("output/reproducibility", exist_ok=True)
os.makedirs("output/final_results", exist_ok=True)

# ============================================================
# REPRODUCIBILITY RESULTS - 3 SEEDS
# ============================================================

results = [
    {
        "seed": 42,
        "threshold": 0.4172005355,
        "accuracy": 0.9882232087,
        "precision": 0.3004291845,
        "recall": 0.3070175439,
        "f1": 0.3036876356,
        "roc_auc": 0.8599011263,
        "pr_auc": 0.2030501244
    },
    {
        "seed": 123,
        "threshold": 0.3187318146,
        "accuracy": 0.9873793888,
        "precision": 0.2883211679,
        "recall": 0.3464912281,
        "f1": 0.3147410359,
        "roc_auc": 0.8578649767,
        "pr_auc": 0.1737694973
    },
    {
        "seed": 2026,
        "threshold": 0.3793354034,
        "accuracy": 0.9877829548,
        "precision": 0.2941176471,
        "recall": 0.3289473684,
        "f1": 0.3105590062,
        "roc_auc": 0.8496252888,
        "pr_auc": 0.1698841739
    }
]

df = pd.DataFrame(results)

# Save individual runs
df.to_csv(
    "output/reproducibility/experiment_D_reproducibility_runs.csv",
    index=False
)

# ============================================================
# MEAN AND STANDARD DEVIATION
# ============================================================

metrics = [
    "accuracy",
    "precision",
    "recall",
    "f1",
    "roc_auc",
    "pr_auc"
]

summary = pd.DataFrame({
    "Metric": metrics,
    "Mean": [df[m].mean() for m in metrics],
    "SD": [df[m].std(ddof=1) for m in metrics]
})

summary.to_csv(
    "output/reproducibility/experiment_D_reproducibility_summary.csv",
    index=False
)

print("\nReproducibility Results:")
print(df)

print("\nMean ± SD:")
print(summary)

# ============================================================
# GRAPH
# ============================================================

graph_metrics = [
    "precision",
    "recall",
    "f1",
    "roc_auc",
    "pr_auc"
]

means = df[graph_metrics].mean()
stds = df[graph_metrics].std(ddof=1)

labels = [
    "Precision",
    "Recall",
    "F1",
    "ROC-AUC",
    "PR-AUC"
]

plt.figure(figsize=(9, 6))

plt.bar(
    labels,
    means,
    yerr=stds,
    capsize=5
)

plt.title(
    "Final SCER-Mamba Reproducibility Across 3 Seeds"
)

plt.ylabel(
    "Mean Score ± Standard Deviation"
)

plt.ylim(0, 1)

plt.tight_layout()

plt.savefig(
    "output/final_results/final_scer_mamba_reproducibility.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()

print("\nSaved:")
print("output/reproducibility/experiment_D_reproducibility_runs.csv")
print("output/reproducibility/experiment_D_reproducibility_summary.csv")
print("output/final_results/final_scer_mamba_reproducibility.png")