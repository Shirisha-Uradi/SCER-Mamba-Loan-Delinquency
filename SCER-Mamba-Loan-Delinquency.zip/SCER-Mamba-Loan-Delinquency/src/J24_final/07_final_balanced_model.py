# ============================================================
# SETUP: GOOGLE DRIVE + J24 DATA + SCER-MAMBA DEFINITIONS
# ------------------------------------------------------------
# Everything is saved to Google Drive, so a Colab reset can't
# delete it. Re-running this cell after a reset continues from
# where it stopped.
# ============================================================

import os
import shutil
import pandas as pd

# ------------------------------------------------------------
# PART 0 - GOOGLE DRIVE
# ------------------------------------------------------------
from google.colab import drive
drive.mount("/content/drive")

DRIVE_DIR = "/content/drive/MyDrive/SCER_Mamba"
os.makedirs(DRIVE_DIR, exist_ok=True)

ZIP_NAME = "sequential_enhanced_model_ready_age24.zip"
drive_zip = f"{DRIVE_DIR}/{ZIP_NAME}"
local_zip = f"/content/{ZIP_NAME}"

if not os.path.exists(drive_zip):
    if not os.path.exists(local_zip):
        print(f"Upload {ZIP_NAME} (from your VS Code Data folder)")
        from google.colab import files
        files.upload()
    shutil.copy(local_zip, drive_zip)
    print("Saved J24 zip to Google Drive - you won't need to upload it again")

if not os.path.exists(local_zip):
    shutil.copy(drive_zip, local_zip)
print("J24 zip ready")


# ------------------------------------------------------------
# PART 1 - RECOVERY (your original recovery cell)
# ------------------------------------------------------------
import os
import zipfile
import random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from torch.utils.data import TensorDataset, DataLoader
from transformers import MambaConfig, MambaModel

# ============================================================
# DEVICE
# ============================================================

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("Using device:", device)


# ============================================================
# UNZIP J24 IF NEEDED
# ============================================================

zip_path = "/content/sequential_enhanced_model_ready_age24.zip"
extract_path = "/content/sequential_enhanced_model_ready_age24"

if not os.path.exists(extract_path):

    if not os.path.exists(zip_path):
        raise FileNotFoundError(
            "Upload sequential_enhanced_model_ready_age24.zip first."
        )

    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(extract_path)

    print("✅ J24 unzipped")


# ============================================================
# FIND FILE
# ============================================================

def find_j24_file(filename):

    for root, dirs, files in os.walk(extract_path):

        if filename in files:
            return os.path.join(root, filename)

    raise FileNotFoundError(filename)


# ============================================================
# LOAD TRAIN + VALIDATION
# ============================================================

X_seq_train_J24 = np.load(
    find_j24_file("X_sequence_train.npy")
)

X_static_train_J24 = np.load(
    find_j24_file("X_static_train.npy")
)

y_train_J24 = np.load(
    find_j24_file("y_train.npy")
)

X_seq_val_J24 = np.load(
    find_j24_file("X_sequence_val.npy")
)

X_static_val_J24 = np.load(
    find_j24_file("X_static_val.npy")
)

y_val_J24 = np.load(
    find_j24_file("y_val.npy")
)


train_dataset_J24 = TensorDataset(
    torch.tensor(X_seq_train_J24, dtype=torch.float32),
    torch.tensor(X_static_train_J24, dtype=torch.float32),
    torch.tensor(y_train_J24, dtype=torch.float32)
)

val_dataset_J24 = TensorDataset(
    torch.tensor(X_seq_val_J24, dtype=torch.float32),
    torch.tensor(X_static_val_J24, dtype=torch.float32),
    torch.tensor(y_val_J24, dtype=torch.float32)
)

val_loader_J24 = DataLoader(
    val_dataset_J24,
    batch_size=256,
    shuffle=False,
    num_workers=2,
    pin_memory=True
)


# ============================================================
# FOCAL LOSS
# ============================================================

class FocalLoss(nn.Module):

    def __init__(self, gamma=2.0):
        super().__init__()
        self.gamma = gamma

    def forward(self, logits, targets):

        targets = targets.float()

        bce = F.binary_cross_entropy_with_logits(
            logits,
            targets,
            reduction="none"
        )

        probs = torch.sigmoid(logits)

        pt = (
            probs * targets
            +
            (1 - probs) * (1 - targets)
        )

        return (
            ((1 - pt) ** self.gamma) * bce
        ).mean()


# ============================================================
# EXPERIMENT K MODEL
# ============================================================

class MultiPoolSCERMamba(nn.Module):

    def __init__(
        self,
        temporal_features=13,
        static_features=12,
        hidden_size=64,
        num_layers=2,
        dropout=0.20
    ):
        super().__init__()

        self.static_encoder = nn.Sequential(
            nn.Linear(static_features, 32),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(32, hidden_size),
            nn.ReLU()
        )

        self.temporal_projection = nn.Linear(
            temporal_features,
            hidden_size
        )

        config = MambaConfig(
            vocab_size=2,
            hidden_size=hidden_size,
            state_size=16,
            num_hidden_layers=num_layers,
            expand=2,
            conv_kernel=4,
            use_cache=False
        )

        self.mamba = MambaModel(config)

        self.output_norm = nn.LayerNorm(
            hidden_size
        )

        self.temporal_attention = nn.Linear(
            hidden_size,
            1
        )

        self.risk_event_attention = nn.Sequential(
            nn.Linear(3, 16),
            nn.ReLU(),
            nn.Linear(16, 1)
        )

        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * 4, 128),
            nn.ReLU(),
            nn.Dropout(dropout),

            nn.Linear(128, 32),
            nn.ReLU(),
            nn.Dropout(dropout),

            nn.Linear(32, 1)
        )

    def forward(self, sequence, static):

        static_embedding = self.static_encoder(
            static
        )

        temporal = self.temporal_projection(
            sequence
        )

        mamba_output = self.mamba(
            inputs_embeds=temporal,
            use_cache=False
        ).last_hidden_state

        mamba_output = self.output_norm(
            mamba_output
        )

        temporal_scores = self.temporal_attention(
            mamba_output
        ).squeeze(-1)

        risk_events = sequence[:, :, 4:7]

        risk_scores = self.risk_event_attention(
            risk_events
        ).squeeze(-1)

        attention_weights = torch.softmax(
            temporal_scores + risk_scores,
            dim=1
        )

        attention_pool = torch.sum(
            mamba_output *
            attention_weights.unsqueeze(-1),
            dim=1
        )

        mean_pool = mamba_output.mean(dim=1)

        final_state = mamba_output[:, -1, :]

        combined = torch.cat(
            [
                attention_pool,
                mean_pool,
                final_state,
                static_embedding
            ],
            dim=1
        )

        logits = self.classifier(
            combined
        ).squeeze(-1)

        return logits, attention_weights


print("\n✅ RECOVERY COMPLETE")
print("Train:", X_seq_train_J24.shape)
print("Validation:", X_seq_val_J24.shape)
print("Risky train:", int(y_train_J24.sum()))
print("Risky validation:", int(y_val_J24.sum()))
print("Device:", device)


# ------------------------------------------------------------
# PART 2 - MODEL DEFINITIONS AND HELPERS
# ------------------------------------------------------------
# ============================================================
# IMPROVEMENT ROUND - FAIR TUNING ON J24
# ------------------------------------------------------------
# Run in the SAME Colab session after the recovery + balancing
# cell (uses X_seq_train_J24, val_loader_J24, test_loader_J24,
# FocalLoss, device).
#
# Fair protocol:
#   1. SCER-Mamba and LSTM each get 8 configurations (same budget)
#   2. Configurations are ranked on VALIDATION PR-AUC only
#   3. Best config of each model -> 3 seeds -> test set ONCE
#
# Resumable: finished configs are saved to CSV, so if Colab
# disconnects, re-run the recovery cell and then this cell and it
# continues where it stopped.
# ============================================================

import os
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from transformers import MambaConfig, MambaModel
from sklearn.metrics import (
    average_precision_score, roc_auc_score, precision_recall_curve,
    precision_score, recall_score, f1_score, confusion_matrix
)

for name in ["X_seq_train_J24", "val_loader_J24", "FocalLoss", "device"]:
    assert name in globals(), f"{name} missing - run the recovery + balancing cell first"

# Test loader (rebuilt here in case the session was restarted)
if "test_loader_J24" not in globals():
    _folder = "/content/sequential_enhanced_model_ready_age24"
    def _find(n):
        for r, _, fs in os.walk(_folder):
            if n in fs:
                return os.path.join(r, n)
        raise FileNotFoundError(n)
    X_seq_test_J24 = np.load(_find("X_sequence_test.npy")).astype(np.float32)
    X_static_test_J24 = np.load(_find("X_static_test.npy")).astype(np.float32)
    y_test_J24 = np.load(_find("y_test.npy")).astype(np.float32)
    test_loader_J24 = DataLoader(
        TensorDataset(torch.tensor(X_seq_test_J24), torch.tensor(X_static_test_J24),
                      torch.tensor(y_test_J24)),
        batch_size=1024, shuffle=False)

y_tr = np.asarray(y_train_J24).astype(int)
y_va = np.asarray(y_val_J24).astype(int)
y_te = np.asarray(y_test_J24).astype(int)

train_ds = TensorDataset(
    torch.tensor(np.asarray(X_seq_train_J24), dtype=torch.float32),
    torch.tensor(np.asarray(X_static_train_J24), dtype=torch.float32),
    torch.tensor(y_tr, dtype=torch.float32)
)

# Set to True to also tune the LSTM with the same budget (fairer, but ~2x longer).
# With False, only SCER-Mamba is tuned; compare against your existing LSTM results
# and state in the report that the LSTM used untuned default settings.
TUNE_LSTM = False

OUT_DIR = "/content/drive/MyDrive/SCER_Mamba/tuning_J24"
os.makedirs(OUT_DIR, exist_ok=True)
SEARCH_CSV = f"{OUT_DIR}/search_results.csv"

# Results already obtained before the Colab reset (seed 42, validation only).
# Pre-filled so the search continues from S5 instead of repeating them.
if not os.path.exists(SEARCH_CSV):
    pd.DataFrame([
        {"Model": "SCER-Mamba", "Config": "S1_base",      "Val_PR_AUC": 0.3007, "Val_ROC_AUC": float("nan")},
        {"Model": "SCER-Mamba", "Config": "S2_hidden128", "Val_PR_AUC": 0.3153, "Val_ROC_AUC": float("nan")},
        {"Model": "SCER-Mamba", "Config": "S3_layers1",   "Val_PR_AUC": 0.3255, "Val_ROC_AUC": float("nan")},
        {"Model": "SCER-Mamba", "Config": "S4_layers3",   "Val_PR_AUC": 0.3255, "Val_ROC_AUC": float("nan")},
    ]).to_csv(SEARCH_CSV, index=False)
    print("Pre-filled S1-S4 results from the previous run")


# ------------------------------------------------------------
# Models
# ------------------------------------------------------------
class TunableSCERMamba(nn.Module):
    """Experiment K architecture, with optional bidirectional Mamba
    and adjustable state size."""

    def __init__(self, temporal_features=13, static_features=12, hidden_size=64,
                 num_layers=2, dropout=0.20, state_size=16, bidirectional=False):
        super().__init__()
        self.static_encoder = nn.Sequential(
            nn.Linear(static_features, 32), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(32, hidden_size), nn.ReLU()
        )
        self.temporal_projection = nn.Linear(temporal_features, hidden_size)

        cfg = MambaConfig(vocab_size=2, hidden_size=hidden_size, state_size=state_size,
                          num_hidden_layers=num_layers, expand=2, conv_kernel=4,
                          use_cache=False)
        self.mamba_fwd = MambaModel(cfg)
        self.mamba_bwd = MambaModel(cfg) if bidirectional else None
        self.output_norm = nn.LayerNorm(hidden_size)

        self.temporal_attention = nn.Linear(hidden_size, 1)
        self.risk_event_attention = nn.Sequential(
            nn.Linear(3, 16), nn.ReLU(), nn.Linear(16, 1)
        )
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * 4, 128), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(128, 32), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(32, 1)
        )

    def forward(self, sequence, static):
        static_embedding = self.static_encoder(static)
        temporal = self.temporal_projection(sequence)

        out = self.mamba_fwd(inputs_embeds=temporal, use_cache=False).last_hidden_state
        if self.mamba_bwd is not None:
            rev = self.mamba_bwd(inputs_embeds=torch.flip(temporal, [1]),
                                 use_cache=False).last_hidden_state
            out = out + torch.flip(rev, [1])
        out = self.output_norm(out)

        scores = (self.temporal_attention(out).squeeze(-1)
                  + self.risk_event_attention(sequence[:, :, 4:7]).squeeze(-1))
        attention_weights = torch.softmax(scores, dim=1)
        attention_pool = torch.sum(out * attention_weights.unsqueeze(-1), dim=1)

        combined = torch.cat([attention_pool, out.mean(dim=1), out[:, -1, :],
                              static_embedding], dim=1)
        return self.classifier(combined).squeeze(-1), attention_weights


class TunableLSTM(nn.Module):
    """Your LSTM baseline, with optional bidirectional LSTM."""

    def __init__(self, temporal_features=13, static_features=12, hidden_size=64,
                 num_layers=2, dropout=0.20, bidirectional=False):
        super().__init__()
        self.bidirectional = bidirectional
        self.lstm = nn.LSTM(input_size=temporal_features, hidden_size=hidden_size,
                            num_layers=num_layers, batch_first=True,
                            dropout=dropout if num_layers > 1 else 0.0,
                            bidirectional=bidirectional)
        self.static_encoder = nn.Sequential(
            nn.Linear(static_features, 32), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(32, hidden_size), nn.ReLU()
        )
        dirs = 2 if bidirectional else 1
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * dirs + hidden_size, 64), nn.ReLU(),
            nn.Dropout(dropout), nn.Linear(64, 1)
        )

    def forward(self, sequence, static):
        _, (h, _) = self.lstm(sequence)
        temporal = torch.cat([h[-2], h[-1]], dim=1) if self.bidirectional else h[-1]
        fused = torch.cat([temporal, self.static_encoder(static)], dim=1)
        return self.classifier(fused).squeeze(-1)


# ------------------------------------------------------------
# Search spaces - 8 configs each (equal budget)
# ------------------------------------------------------------
BASE = dict(hidden_size=64, num_layers=2, dropout=0.20, lr=3e-4, weight_decay=1e-4)

SCER_CONFIGS = {
    "S1_base":          dict(BASE),
    "S2_hidden128":     dict(BASE, hidden_size=128),
    "S3_layers1":       dict(BASE, num_layers=1),
    "S4_layers3":       dict(BASE, num_layers=3),
    "S5_lr1e-3":        dict(BASE, lr=1e-3),
    "S6_reg_strong":    dict(BASE, dropout=0.30, weight_decay=1e-3),
    "S7_state32":       dict(BASE, state_size=32),
    "S8_bidirectional": dict(BASE, bidirectional=True),
}

LSTM_CONFIGS = {
    "L1_base":          dict(BASE),
    "L2_hidden128":     dict(BASE, hidden_size=128),
    "L3_layers1":       dict(BASE, num_layers=1),
    "L4_layers3":       dict(BASE, num_layers=3),
    "L5_lr1e-3":        dict(BASE, lr=1e-3),
    "L6_reg_strong":    dict(BASE, dropout=0.30, weight_decay=1e-3),
    "L7_hidden32":      dict(BASE, hidden_size=32),
    "L8_bidirectional": dict(BASE, bidirectional=True),
}

MODEL_KEYS = {"hidden_size", "num_layers", "dropout", "state_size", "bidirectional"}


def build(kind, cfg):
    kwargs = {k: v for k, v in cfg.items() if k in MODEL_KEYS}
    if kind == "SCER-Mamba":
        return TunableSCERMamba(**kwargs).to(device)
    kwargs.pop("state_size", None)
    return TunableLSTM(**kwargs).to(device)


# ------------------------------------------------------------
# Training / prediction
# ------------------------------------------------------------
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def predict(model, loader):
    model.eval()
    out = []
    with torch.no_grad():
        for seq, stat, _ in loader:
            logits = model(seq.to(device), stat.to(device))
            if isinstance(logits, tuple):
                logits = logits[0]
            out.append(torch.sigmoid(logits).cpu().numpy())
    return np.concatenate(out)


def train(kind, name, cfg, seed, max_epochs=20, patience=4):
    path = f"{OUT_DIR}/{name}_seed{seed}.pt"
    model = build(kind, cfg)
    if os.path.exists(path):
        model.load_state_dict(torch.load(path, map_location=device))
        print(f"[{name} seed {seed}] already trained - loaded")
        return model, average_precision_score(y_va, predict(model, val_loader_J24))

    set_seed(seed)
    model = build(kind, cfg)
    loader = DataLoader(train_ds, batch_size=256, shuffle=True,
                        generator=torch.Generator().manual_seed(seed),
                        num_workers=2, pin_memory=True)
    criterion = FocalLoss(gamma=2.0)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg["lr"],
                                  weight_decay=cfg["weight_decay"])

    best, bad = -1, 0
    for epoch in range(max_epochs):
        model.train()
        for seq, stat, tgt in loader:
            seq, stat, tgt = seq.to(device), stat.to(device), tgt.to(device)
            optimizer.zero_grad()
            logits = model(seq, stat)
            if isinstance(logits, tuple):
                logits = logits[0]
            loss = criterion(logits, tgt)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

        pr = average_precision_score(y_va, predict(model, val_loader_J24))
        print(f"[{name} seed {seed}] Epoch {epoch + 1:02d} | Val PR-AUC {pr:.4f}")
        if pr > best:
            best, bad = pr, 0
            torch.save(model.state_dict(), path)
        else:
            bad += 1
            if bad >= patience:
                print(f"[{name} seed {seed}] Early stopping")
                break

    model.load_state_dict(torch.load(path, map_location=device))
    return model, best




# ============================================================
# PART 3 - FINAL MODEL ON BALANCED DATA
# ============================================================
# ============================================================
# FINAL MODEL ON BALANCED DATA - SCER-MAMBA (J24)
# ------------------------------------------------------------
# SELF-CONTAINED: run this cell on its own (after
# !pip install -U transformers). Everything is saved to Drive.
#
# - Uses the BEST tuned SCER-Mamba config
# - Training data balanced 50/50 by random oversampling (1:1)
# - Validation and test keep the real ratio (1.05% risky)
# - 3 seeds, threshold chosen on validation, test evaluated once
# ============================================================

import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import (
    average_precision_score, roc_auc_score, precision_recall_curve,
    accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
)

FINAL_DIR = f"{OUT_DIR}/final_balanced"
os.makedirs(FINAL_DIR, exist_ok=True)

y_tr = np.asarray(y_train_J24).astype(int)
y_va = np.asarray(y_val_J24).astype(int)
y_te = np.asarray(y_test_J24).astype(int)
X_seq_tr = np.asarray(X_seq_train_J24, dtype=np.float32)
X_sta_tr = np.asarray(X_static_train_J24, dtype=np.float32)

# Best config from the tuning round (chosen on validation).
# If the tuning round has not finished, use the best one found so far.
search_path = f"{OUT_DIR}/search_results.csv"
if os.path.exists(search_path):
    search = pd.read_csv(search_path)
    best_name = (search[search["Model"] == "SCER-Mamba"]
                 .sort_values("Val_PR_AUC", ascending=False, kind="mergesort").iloc[0]["Config"])
    print(f"Configs searched so far: {len(search)} of 8")
else:
    best_name = "S3_layers1"
    print("No search results on Drive yet - using S3_layers1 (best so far, val PR-AUC 0.3255)")
best_cfg = SCER_CONFIGS[best_name]
print("Best tuned SCER-Mamba config:", best_name, best_cfg)


# ------------------------------------------------------------
# Balance the TRAINING data: random oversampling to 1:1
# ------------------------------------------------------------
def balanced_indices(y, seed):
    rng = np.random.default_rng(seed)
    pos = np.where(y == 1)[0]
    neg = np.where(y == 0)[0]
    extra = rng.choice(pos, size=len(neg) - len(pos), replace=True)
    idx = np.concatenate([neg, pos, extra])
    rng.shuffle(idx)
    return idx


def counts(name, y):
    return {"Data": name, "Risky": int(y.sum()), "Not risky": int((y == 0).sum()),
            "Total": len(y), "Risky %": round(100 * y.mean(), 2)}


bal_y = y_tr[balanced_indices(y_tr, 42)]
counts_df = pd.DataFrame([
    counts("Train - before balancing", y_tr),
    counts("Train - after balancing", bal_y),
    counts("Validation (not balanced)", y_va),
    counts("Test (not balanced)", y_te),
])
print("\n" + "=" * 70 + "\nDATA BEFORE AND AFTER BALANCING\n" + "=" * 70)
print(counts_df.to_string(index=False))
counts_df.to_csv(f"{FINAL_DIR}/balanced_label_counts.csv", index=False)


# ------------------------------------------------------------
# Train on balanced data
# ------------------------------------------------------------
def train_balanced(seed, max_epochs=20, patience=4):
    path = f"{FINAL_DIR}/balanced_{best_name}_seed{seed}.pt"
    model = build("SCER-Mamba", best_cfg)
    if os.path.exists(path):
        model.load_state_dict(torch.load(path, map_location=device))
        print(f"[seed {seed}] loaded {path}")
        return model

    set_seed(seed)
    model = build("SCER-Mamba", best_cfg)
    idx = balanced_indices(y_tr, seed)
    ds = TensorDataset(torch.from_numpy(X_seq_tr[idx]), torch.from_numpy(X_sta_tr[idx]),
                       torch.tensor(y_tr[idx], dtype=torch.float32))
    loader = DataLoader(ds, batch_size=256, shuffle=True,
                        generator=torch.Generator().manual_seed(seed),
                        num_workers=2, pin_memory=True)

    # Data is already balanced, so plain BCE (focal loss would double-correct)
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=best_cfg["lr"],
                                  weight_decay=best_cfg["weight_decay"])

    best, bad = -1, 0
    for epoch in range(max_epochs):
        model.train()
        for seq, stat, tgt in loader:
            seq, stat, tgt = seq.to(device), stat.to(device), tgt.to(device)
            optimizer.zero_grad()
            logits, _ = model(seq, stat)
            loss = criterion(logits, tgt)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

        pr = average_precision_score(y_va, predict(model, val_loader_J24))
        print(f"[seed {seed}] Epoch {epoch + 1:02d} | Val PR-AUC {pr:.4f}")
        if pr > best:
            best, bad = pr, 0
            torch.save(model.state_dict(), path)
        else:
            bad += 1
            if bad >= patience:
                print(f"[seed {seed}] Early stopping")
                break

    del ds, loader
    model.load_state_dict(torch.load(path, map_location=device))
    return model


def evaluate(val_probs, test_probs):
    p, r, t = precision_recall_curve(y_va, val_probs)
    f1s = 2 * p[:-1] * r[:-1] / (p[:-1] + r[:-1] + 1e-10)
    thr = float(t[int(np.argmax(f1s))])
    pred = (test_probs >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_te, pred).ravel()
    return {"Threshold": thr,
            "Accuracy": accuracy_score(y_te, pred),
            "Precision": precision_score(y_te, pred, zero_division=0),
            "Recall": recall_score(y_te, pred, zero_division=0),
            "F1": f1_score(y_te, pred, zero_division=0),
            "ROC_AUC": roc_auc_score(y_te, test_probs),
            "PR_AUC": average_precision_score(y_te, test_probs),
            "TP": int(tp), "FP": int(fp), "FN": int(fn), "TN": int(tn)}


rows, vals, tests = [], [], []
for seed in [42, 123, 2026]:
    print("\n" + "=" * 60 + f"\nBALANCED TRAINING - SEED {seed}\n" + "=" * 60)
    model = train_balanced(seed)
    vp, tp_ = predict(model, val_loader_J24), predict(model, test_loader_J24)
    vals.append(vp)
    tests.append(tp_)
    rows.append({"Seed": seed, **evaluate(vp, tp_)})
    del model
    torch.cuda.empty_cache()

res = pd.DataFrame(rows)
ens = evaluate(np.mean(vals, axis=0), np.mean(tests, axis=0))

cols = ["Accuracy", "Precision", "Recall", "F1", "ROC_AUC", "PR_AUC", "TP", "FP", "FN", "TN"]
print("\n" + "=" * 70 + f"\nFINAL SCER-MAMBA ({best_name}) ON BALANCED DATA - TEST SET\n" + "=" * 70)
print(res[["Seed"] + cols].round(4).to_string(index=False))

print("\nMEAN +/- SD OVER 3 SEEDS")
for c in ["Accuracy", "Precision", "Recall", "F1", "ROC_AUC", "PR_AUC"]:
    print(f"  {c:<9}: {res[c].mean():.4f} +/- {res[c].std():.4f}")

print("\n3-SEED ENSEMBLE")
print("  " + "  ".join(f"{c}: {ens[c]:.4f}" for c in
                       ["Accuracy", "Precision", "Recall", "F1", "ROC_AUC", "PR_AUC"]))

print("\nFor comparison - LSTM (3 seeds, test): "
      "PR-AUC 0.3640 +/- 0.0037, F1 0.4518 +/- 0.0107, ROC-AUC 0.9214 +/- 0.0011")

res.to_csv(f"{FINAL_DIR}/balanced_3seeds_test.csv", index=False)
pd.DataFrame([{"Model": "3-seed ensemble", **ens}]).to_csv(
    f"{FINAL_DIR}/balanced_ensemble_test.csv", index=False)
print(f"\nSaved in {FINAL_DIR}/")
