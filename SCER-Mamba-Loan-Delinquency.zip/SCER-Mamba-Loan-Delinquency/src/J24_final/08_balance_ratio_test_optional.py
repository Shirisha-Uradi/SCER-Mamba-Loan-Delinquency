# ============================================================
# BALANCING-RATIO TEST FOR THE TUNED SCER-MAMBA (J24)
# ------------------------------------------------------------
# Run AFTER tuning_with_drive_J24.py has finished, in the same
# Colab session. (If Colab reset, run tuning_with_drive_J24.py
# again first - it finishes quickly because everything is saved
# on Drive - then run this cell.)
#
# Compares, using the BEST tuned SCER-Mamba config:
#   A. Focal loss, no resampling (current method)
#   B. Oversampling 1:1  (50% risky)
#   C. Oversampling 1:4  (20% risky)
#   D. Oversampling 1:10 (~9% risky)
#
# Selection: validation PR-AUC (seed 42).
# Winner: 3 seeds on the test set.
# Only TRAINING data is resampled. Validation/test keep 1.05%.
# ============================================================

import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import (
    average_precision_score, roc_auc_score, precision_recall_curve,
    accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
)

for name in ["SCER_CONFIGS", "TunableSCERMamba", "build", "predict", "set_seed",
             "FocalLoss", "X_seq_train_J24", "val_loader_J24", "test_loader_J24", "OUT_DIR"]:
    assert name in globals(), f"{name} missing - run tuning_with_drive_J24.py first"

BAL_DIR = f"{OUT_DIR}/balance_ratio"
os.makedirs(BAL_DIR, exist_ok=True)
BAL_CSV = f"{BAL_DIR}/balance_ratio_results.csv"

y_tr = np.asarray(y_train_J24).astype(int)
y_va = np.asarray(y_val_J24).astype(int)
y_te = np.asarray(y_test_J24).astype(int)

X_seq_tr = np.asarray(X_seq_train_J24, dtype=np.float32)
X_sta_tr = np.asarray(X_static_train_J24, dtype=np.float32)

# ------------------------------------------------------------
# Best tuned config (chosen on validation in the tuning round)
# ------------------------------------------------------------
search = pd.read_csv(f"{OUT_DIR}/search_results.csv")
best_name = (search[search["Model"] == "SCER-Mamba"]
             .sort_values("Val_PR_AUC", ascending=False).iloc[0]["Config"])
best_cfg = SCER_CONFIGS[best_name]
print("Best tuned SCER-Mamba config:", best_name, best_cfg)


# ------------------------------------------------------------
# Resampling (training set only)
# ------------------------------------------------------------
def oversample_indices(y, ratio, seed=42):
    """ratio = not-risky per risky loan (1 -> 1:1, 4 -> 1:4, 10 -> 1:10)."""
    rng = np.random.default_rng(seed)
    pos = np.where(y == 1)[0]
    neg = np.where(y == 0)[0]
    target_pos = int(round(len(neg) / ratio))
    extra = rng.choice(pos, size=max(target_pos - len(pos), 0), replace=True)
    idx = np.concatenate([neg, pos, extra])
    rng.shuffle(idx)
    return idx


VARIANTS = {
    "A_focal_no_resampling": dict(ratio=None, loss="focal"),
    "B_oversample_1to1":     dict(ratio=1,    loss="bce"),
    "C_oversample_1to4":     dict(ratio=4,    loss="bce"),
    "D_oversample_1to10":    dict(ratio=10,   loss="bce"),
}

# Show label counts for every variant
count_rows = []
for vname, v in VARIANTS.items():
    idx = np.arange(len(y_tr)) if v["ratio"] is None else oversample_indices(y_tr, v["ratio"])
    yy = y_tr[idx]
    count_rows.append({"Variant": vname, "Train risky": int(yy.sum()),
                       "Train not risky": int((yy == 0).sum()),
                       "Risky %": round(100 * yy.mean(), 2),
                       "Val (risky/not)": f"{y_va.sum()} / {(y_va == 0).sum()}",
                       "Test (risky/not)": f"{y_te.sum()} / {(y_te == 0).sum()}"})
counts_df = pd.DataFrame(count_rows)
print("\n" + "=" * 70 + "\nLABEL COUNTS PER VARIANT\n" + "=" * 70)
print(counts_df.to_string(index=False))
counts_df.to_csv(f"{BAL_DIR}/balance_ratio_label_counts.csv", index=False)


# ------------------------------------------------------------
# Training
# ------------------------------------------------------------
def train_variant(vname, v, seed, max_epochs=20, patience=4):
    path = f"{BAL_DIR}/{vname}_seed{seed}.pt"

    # Variant A with the tuned config is exactly the tuning-round model
    if v["ratio"] is None:
        tuned_path = f"{OUT_DIR}/{best_name}_seed{seed}.pt"
        if os.path.exists(tuned_path):
            path = tuned_path

    model = build("SCER-Mamba", best_cfg)
    if os.path.exists(path):
        model.load_state_dict(torch.load(path, map_location=device))
        print(f"[{vname} seed {seed}] loaded {path}")
        return model

    set_seed(seed)
    model = build("SCER-Mamba", best_cfg)
    idx = np.arange(len(y_tr)) if v["ratio"] is None else oversample_indices(y_tr, v["ratio"], seed)
    ds = TensorDataset(torch.from_numpy(X_seq_tr[idx]), torch.from_numpy(X_sta_tr[idx]),
                       torch.tensor(y_tr[idx], dtype=torch.float32))
    loader = DataLoader(ds, batch_size=256, shuffle=True,
                        generator=torch.Generator().manual_seed(seed),
                        num_workers=2, pin_memory=True)
    criterion = FocalLoss(gamma=2.0) if v["loss"] == "focal" else nn.BCEWithLogitsLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=best_cfg["lr"],
                                  weight_decay=best_cfg["weight_decay"])

    best, bad = -1, 0
    for epoch in range(max_epochs):
        model.train()
        for seq, stat, tgt in loader:
            seq, stat, tgt = seq.to(device), stat.to(device), tgt.to(device)
            optimizer.zero_grad()
            logits, _ = model(seq, stat)
            loss = criterion(logits, tgt)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

        pr = average_precision_score(y_va, predict(model, val_loader_J24))
        print(f"[{vname} seed {seed}] Epoch {epoch + 1:02d} | Val PR-AUC {pr:.4f}")
        if pr > best:
            best, bad = pr, 0
            torch.save(model.state_dict(), path)
        else:
            bad += 1
            if bad >= patience:
                print(f"[{vname} seed {seed}] Early stopping")
                break

    del ds, loader
    model.load_state_dict(torch.load(path, map_location=device))
    return model


def evaluate(val_probs, test_probs):
    p, r, t = precision_recall_curve(y_va, val_probs)
    f1s = 2 * p[:-1] * r[:-1] / (p[:-1] + r[:-1] + 1e-10)
    thr = float(t[int(np.argmax(f1s))])
    pred = (test_probs >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_te, pred).ravel()
    return {"Threshold": thr,
            "Val_PR_AUC": average_precision_score(y_va, val_probs),
            "Accuracy": accuracy_score(y_te, pred),
            "Precision": precision_score(y_te, pred, zero_division=0),
            "Recall": recall_score(y_te, pred, zero_division=0),
            "F1": f1_score(y_te, pred, zero_division=0),
            "ROC_AUC": roc_auc_score(y_te, test_probs),
            "PR_AUC": average_precision_score(y_te, test_probs),
            "TP": int(tp), "FP": int(fp), "FN": int(fn), "TN": int(tn)}


# ------------------------------------------------------------
# STEP 1 - each variant, seed 42
# ------------------------------------------------------------
done = pd.read_csv(BAL_CSV) if os.path.exists(BAL_CSV) else pd.DataFrame()
for vname, v in VARIANTS.items():
    if len(done) and vname in set(done["Variant"]):
        print(f"Skipping {vname} (already done)")
        continue
    print("\n" + "=" * 60 + f"\n{vname}\n" + "=" * 60)
    model = train_variant(vname, v, seed=42)
    row = {"Variant": vname, **evaluate(predict(model, val_loader_J24),
                                        predict(model, test_loader_J24))}
    done = pd.concat([done, pd.DataFrame([row])], ignore_index=True)
    done.to_csv(BAL_CSV, index=False)
    del model
    torch.cuda.empty_cache()

cols = ["Val_PR_AUC", "Accuracy", "Precision", "Recall", "F1", "ROC_AUC", "PR_AUC", "TP", "FP", "FN"]
print("\n" + "=" * 70 + "\nBALANCING-RATIO COMPARISON (seed 42, test set)\n" + "=" * 70)
print(done[["Variant"] + cols].round(4).to_string(index=False))


# ------------------------------------------------------------
# STEP 2 - winner chosen on VALIDATION -> 3 seeds on test
# ------------------------------------------------------------
winner = done.sort_values("Val_PR_AUC", ascending=False).iloc[0]["Variant"]
print(f"\nWINNER (by validation PR-AUC): {winner}")

seed_rows = []
for seed in [42, 123, 2026]:
    model = train_variant(winner, VARIANTS[winner], seed)
    seed_rows.append({"Variant": winner, "Seed": seed,
                      **evaluate(predict(model, val_loader_J24),
                                 predict(model, test_loader_J24))})
    del model
    torch.cuda.empty_cache()

seed_df = pd.DataFrame(seed_rows)
seed_df.to_csv(f"{BAL_DIR}/winner_3seeds_test.csv", index=False)

print("\n" + "=" * 70 + f"\nWINNER {winner} - 3 SEEDS (test set)\n" + "=" * 70)
print(seed_df[["Seed"] + cols[1:]].round(4).to_string(index=False))
print("\nMEAN +/- SD")
for c in ["Precision", "Recall", "F1", "ROC_AUC", "PR_AUC"]:
    print(f"  {c:<9}: {seed_df[c].mean():.4f} +/- {seed_df[c].std():.4f}")

print("\nFor comparison - LSTM (3 seeds, test): "
      "PR-AUC 0.3640 +/- 0.0037, F1 0.4518 +/- 0.0107, ROC-AUC 0.9214 +/- 0.0011")
print(f"\nAll results saved in {BAL_DIR}/")
