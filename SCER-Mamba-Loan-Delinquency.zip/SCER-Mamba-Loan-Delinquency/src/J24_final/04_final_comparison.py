# ============================================================
# FINAL COMPARISON - J24 HELD-OUT TEST SET
# ------------------------------------------------------------
# Run in the SAME Colab session, right after the
# recovery + balancing cell (it reuses the loaded J24 data,
# MultiPoolSCERMamba, FocalLoss, val_loader_J24, test_loader_J24).
#
# Produces one final table with:
#   - Rule baseline (currently 30+ days late)
#   - Logistic Regression
#   - XGBoost
#   - LSTM          x 3 seeds (mean +/- SD) + seed ensemble
#   - SCER-Mamba K  x 3 seeds (mean +/- SD) + seed ensemble
#
# All models: trained on the real class ratio, threshold chosen
# on validation, then applied once to the test set.
# ============================================================

import os
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    average_precision_score, roc_auc_score, precision_recall_curve,
    accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
)

for name in ["X_seq_train_J24", "X_seq_test_J24", "val_loader_J24",
             "test_loader_J24", "MultiPoolSCERMamba", "FocalLoss"]:
    assert name in globals(), f"{name} missing - run the recovery + balancing cell first"

SEEDS = [42, 123, 2026]

y_tr = np.asarray(y_train_J24).astype(int)
y_va = np.asarray(y_val_J24).astype(int)
y_te = np.asarray(y_test_J24).astype(int)


# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def best_f1_threshold(y_true, probs):
    p, r, t = precision_recall_curve(y_true, probs)
    f1 = 2 * p[:-1] * r[:-1] / (p[:-1] + r[:-1] + 1e-10)
    return float(t[int(np.argmax(f1))])


def metrics(name, val_probs, test_probs):
    thr = best_f1_threshold(y_va, val_probs)
    pred = (test_probs >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_te, pred).ravel()
    return {
        "Model": name,
        "Threshold": thr,
        "Accuracy": accuracy_score(y_te, pred),
        "Precision": precision_score(y_te, pred, zero_division=0),
        "Recall": recall_score(y_te, pred, zero_division=0),
        "F1": f1_score(y_te, pred, zero_division=0),
        "ROC_AUC": roc_auc_score(y_te, test_probs),
        "PR_AUC": average_precision_score(y_te, test_probs),
        "TP": int(tp), "FP": int(fp), "FN": int(fn), "TN": int(tn),
    }


def predict(model, loader):
    model.eval()
    out = []
    with torch.no_grad():
        for seq, stat, _ in loader:
            logits = model(seq.to(device), stat.to(device))
            if isinstance(logits, tuple):
                logits = logits[0]
            out.append(torch.sigmoid(logits).cpu().numpy())
    return np.concatenate(out)


# ------------------------------------------------------------
# LSTM baseline (same as your notebook)
# ------------------------------------------------------------
class LSTMBaseline(nn.Module):
    def __init__(self, temporal_features=13, static_features=12,
                 hidden_size=64, num_layers=2, dropout=0.20):
        super().__init__()
        self.lstm = nn.LSTM(input_size=temporal_features, hidden_size=hidden_size,
                            num_layers=num_layers, batch_first=True, dropout=dropout)
        self.static_encoder = nn.Sequential(
            nn.Linear(static_features, 32), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(32, hidden_size), nn.ReLU()
        )
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * 2, 64), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(64, 1)
        )

    def forward(self, sequence, static):
        _, (hidden, _) = self.lstm(sequence)
        fused = torch.cat([hidden[-1], self.static_encoder(static)], dim=1)
        return self.classifier(fused).squeeze(-1)


def build(kind):
    if kind == "SCER-Mamba K":
        return MultiPoolSCERMamba(temporal_features=13, static_features=12,
                                  hidden_size=64, num_layers=2, dropout=0.20).to(device)
    return LSTMBaseline().to(device)


train_ds = TensorDataset(
    torch.tensor(np.asarray(X_seq_train_J24), dtype=torch.float32),
    torch.tensor(np.asarray(X_static_train_J24), dtype=torch.float32),
    torch.tensor(y_tr, dtype=torch.float32)
)


def train_one(kind, seed, max_epochs=20, patience=4):
    tag = "K" if kind == "SCER-Mamba K" else "LSTM"
    path = f"/content/final_{tag}_seed_{seed}.pt"

    # Reuse already-trained models to save time
    reuse = {("K", 42): "/content/balancing_Original.pt"}
    for candidate in [path, reuse.get((tag, seed), ""), f"/content/{tag}_seed_{seed}.pt"]:
        if candidate and os.path.exists(candidate):
            model = build(kind)
            model.load_state_dict(torch.load(candidate, map_location=device))
            print(f"[{kind} seed {seed}] loaded {candidate}")
            return model

    set_seed(seed)
    loader = DataLoader(train_ds, batch_size=256, shuffle=True,
                        generator=torch.Generator().manual_seed(seed),
                        num_workers=2, pin_memory=True)
    model = build(kind)
    criterion = FocalLoss(gamma=2.0)
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.0003, weight_decay=0.0001)

    best, bad = -1, 0
    for epoch in range(max_epochs):
        model.train()
        for seq, stat, tgt in loader:
            seq, stat, tgt = seq.to(device), stat.to(device), tgt.to(device)
            optimizer.zero_grad()
            logits = model(seq, stat)
            if isinstance(logits, tuple):
                logits = logits[0]
            loss = criterion(logits, tgt)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

        pr = average_precision_score(y_va, predict(model, val_loader_J24))
        print(f"[{kind} seed {seed}] Epoch {epoch + 1:02d} | Val PR-AUC {pr:.4f}")
        if pr > best:
            best, bad = pr, 0
            torch.save(model.state_dict(), path)
        else:
            bad += 1
            if bad >= patience:
                print(f"[{kind} seed {seed}] Early stopping")
                break

    model.load_state_dict(torch.load(path, map_location=device))
    return model


# ------------------------------------------------------------
# 1. Deep models: 3 seeds each + seed ensemble
# ------------------------------------------------------------
seed_rows, final_rows = [], []

for kind in ["LSTM", "SCER-Mamba K"]:
    val_list, test_list = [], []
    for seed in SEEDS:
        model = train_one(kind, seed)
        vp, tp_ = predict(model, val_loader_J24), predict(model, test_loader_J24)
        val_list.append(vp)
        test_list.append(tp_)
        row = metrics(kind, vp, tp_)
        row["Seed"] = seed
        seed_rows.append(row)
        del model
        torch.cuda.empty_cache()

    # Seed ensemble: average the 3 models' probabilities
    final_rows.append(metrics(f"{kind} (3-seed ensemble)",
                              np.mean(val_list, axis=0), np.mean(test_list, axis=0)))

seed_df = pd.DataFrame(seed_rows)


# ------------------------------------------------------------
# 2. Simple baselines on hand-made features
# ------------------------------------------------------------
def tabular_features(X_seq, X_static):
    X_seq = np.asarray(X_seq)
    return np.hstack([
        np.asarray(X_static),
        X_seq[:, -1, :],               # last month
        X_seq[:, -3:, :].mean(axis=1),  # last 3 months average
        X_seq.mean(axis=1),            # 24-month average
        X_seq.max(axis=1),             # 24-month worst value
    ])


F_tr = tabular_features(X_seq_train_J24, X_static_train_J24)
F_va = tabular_features(X_seq_val_J24, X_static_val_J24)
F_te = tabular_features(X_seq_test_J24, X_static_test_J24)
print("\nTabular feature shape:", F_tr.shape)

# 2a. Rule: flag loan if it is 30+ days late in the last month
#     (column 4 = is_30plus_delinquent; it is standardised, so > 0 means 1)
rule_val = (np.asarray(X_seq_val_J24)[:, -1, 4] > 0).astype(float)
rule_test = (np.asarray(X_seq_test_J24)[:, -1, 4] > 0).astype(float)
pred = rule_test.astype(int)
tn, fp, fn, tp_ = confusion_matrix(y_te, pred).ravel()
final_rows.append({
    "Model": "Rule: currently 30+ days late", "Threshold": 0.5,
    "Accuracy": accuracy_score(y_te, pred),
    "Precision": precision_score(y_te, pred, zero_division=0),
    "Recall": recall_score(y_te, pred, zero_division=0),
    "F1": f1_score(y_te, pred, zero_division=0),
    "ROC_AUC": roc_auc_score(y_te, rule_test),
    "PR_AUC": average_precision_score(y_te, rule_test),
    "TP": int(tp_), "FP": int(fp), "FN": int(fn), "TN": int(tn),
})

# 2b. Logistic Regression
scaler = StandardScaler().fit(F_tr)
lr = LogisticRegression(max_iter=2000, class_weight="balanced", C=1.0)
lr.fit(scaler.transform(F_tr), y_tr)
final_rows.append(metrics("Logistic Regression",
                          lr.predict_proba(scaler.transform(F_va))[:, 1],
                          lr.predict_proba(scaler.transform(F_te))[:, 1]))

# 2c. XGBoost
try:
    import xgboost as xgb
except ImportError:
    os.system("pip install -q xgboost")
    import xgboost as xgb

xgb_model = xgb.XGBClassifier(
    n_estimators=1000, learning_rate=0.03, max_depth=5,
    subsample=0.8, colsample_bytree=0.8, min_child_weight=5,
    eval_metric="aucpr", early_stopping_rounds=50,
    tree_method="hist", random_state=42
)
xgb_model.fit(F_tr, y_tr, eval_set=[(F_va, y_va)], verbose=False)
print("XGBoost best iteration:", xgb_model.best_iteration)
final_rows.append(metrics("XGBoost",
                          xgb_model.predict_proba(F_va)[:, 1],
                          xgb_model.predict_proba(F_te)[:, 1]))


# ------------------------------------------------------------
# 3. Final tables
# ------------------------------------------------------------
cols = ["Precision", "Recall", "F1", "ROC_AUC", "PR_AUC"]

summary = seed_df.groupby("Model")[cols].agg(["mean", "std"])
summary.columns = [f"{m}_{s}" for m, s in summary.columns]
summary = summary.reset_index()

print("\n" + "=" * 70)
print("PER-SEED TEST RESULTS")
print("=" * 70)
print(seed_df[["Model", "Seed"] + cols + ["TP", "FP", "FN"]].round(4).to_string(index=False))

print("\n" + "=" * 70)
print("MEAN +/- SD OVER 3 SEEDS")
print("=" * 70)
for _, r in summary.iterrows():
    print(f"{r['Model']:<14} " + "  ".join(
        f"{c}: {r[c + '_mean']:.4f} +/- {r[c + '_std']:.4f}" for c in cols))

final_df = pd.DataFrame(final_rows)
print("\n" + "=" * 70)
print("BASELINES AND SEED ENSEMBLES")
print("=" * 70)
print(final_df[["Model"] + cols + ["TP", "FP", "FN"]].round(4).to_string(index=False))

seed_df.to_csv("/content/final_per_seed_results.csv", index=False)
summary.to_csv("/content/final_mean_sd_results.csv", index=False)
final_df.to_csv("/content/final_baselines_and_ensembles.csv", index=False)
print("\nSaved: final_per_seed_results.csv, final_mean_sd_results.csv, "
      "final_baselines_and_ensembles.csv")
