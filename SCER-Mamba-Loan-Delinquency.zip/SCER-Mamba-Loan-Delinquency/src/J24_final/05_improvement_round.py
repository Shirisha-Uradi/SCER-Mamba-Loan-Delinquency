# ============================================================
# IMPROVEMENT ROUND - FAIR TUNING ON J24
# ------------------------------------------------------------
# Run in the SAME Colab session after the recovery + balancing
# cell (uses X_seq_train_J24, val_loader_J24, test_loader_J24,
# FocalLoss, device).
#
# Fair protocol:
#   1. SCER-Mamba and LSTM each get 8 configurations (same budget)
#   2. Configurations are ranked on VALIDATION PR-AUC only
#   3. Best config of each model -> 3 seeds -> test set ONCE
#
# Resumable: finished configs are saved to CSV, so if Colab
# disconnects, re-run the recovery cell and then this cell and it
# continues where it stopped.
# ============================================================

import os
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from transformers import MambaConfig, MambaModel
from sklearn.metrics import (
    average_precision_score, roc_auc_score, precision_recall_curve,
    precision_score, recall_score, f1_score, confusion_matrix
)

for name in ["X_seq_train_J24", "val_loader_J24", "FocalLoss", "device"]:
    assert name in globals(), f"{name} missing - run the recovery + balancing cell first"

# Test loader (rebuilt here in case the session was restarted)
if "test_loader_J24" not in globals():
    _folder = "/content/sequential_enhanced_model_ready_age24"
    def _find(n):
        for r, _, fs in os.walk(_folder):
            if n in fs:
                return os.path.join(r, n)
        raise FileNotFoundError(n)
    X_seq_test_J24 = np.load(_find("X_sequence_test.npy")).astype(np.float32)
    X_static_test_J24 = np.load(_find("X_static_test.npy")).astype(np.float32)
    y_test_J24 = np.load(_find("y_test.npy")).astype(np.float32)
    test_loader_J24 = DataLoader(
        TensorDataset(torch.tensor(X_seq_test_J24), torch.tensor(X_static_test_J24),
                      torch.tensor(y_test_J24)),
        batch_size=1024, shuffle=False)

y_tr = np.asarray(y_train_J24).astype(int)
y_va = np.asarray(y_val_J24).astype(int)
y_te = np.asarray(y_test_J24).astype(int)

train_ds = TensorDataset(
    torch.tensor(np.asarray(X_seq_train_J24), dtype=torch.float32),
    torch.tensor(np.asarray(X_static_train_J24), dtype=torch.float32),
    torch.tensor(y_tr, dtype=torch.float32)
)

# Set to True to also tune the LSTM with the same budget (fairer, but ~2x longer).
# With False, only SCER-Mamba is tuned; compare against your existing LSTM results
# and state in the report that the LSTM used untuned default settings.
TUNE_LSTM = False

OUT_DIR = "/content/tuning_J24"
os.makedirs(OUT_DIR, exist_ok=True)
SEARCH_CSV = f"{OUT_DIR}/search_results.csv"


# ------------------------------------------------------------
# Models
# ------------------------------------------------------------
class TunableSCERMamba(nn.Module):
    """Experiment K architecture, with optional bidirectional Mamba
    and adjustable state size."""

    def __init__(self, temporal_features=13, static_features=12, hidden_size=64,
                 num_layers=2, dropout=0.20, state_size=16, bidirectional=False):
        super().__init__()
        self.static_encoder = nn.Sequential(
            nn.Linear(static_features, 32), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(32, hidden_size), nn.ReLU()
        )
        self.temporal_projection = nn.Linear(temporal_features, hidden_size)

        cfg = MambaConfig(vocab_size=2, hidden_size=hidden_size, state_size=state_size,
                          num_hidden_layers=num_layers, expand=2, conv_kernel=4,
                          use_cache=False)
        self.mamba_fwd = MambaModel(cfg)
        self.mamba_bwd = MambaModel(cfg) if bidirectional else None
        self.output_norm = nn.LayerNorm(hidden_size)

        self.temporal_attention = nn.Linear(hidden_size, 1)
        self.risk_event_attention = nn.Sequential(
            nn.Linear(3, 16), nn.ReLU(), nn.Linear(16, 1)
        )
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * 4, 128), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(128, 32), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(32, 1)
        )

    def forward(self, sequence, static):
        static_embedding = self.static_encoder(static)
        temporal = self.temporal_projection(sequence)

        out = self.mamba_fwd(inputs_embeds=temporal, use_cache=False).last_hidden_state
        if self.mamba_bwd is not None:
            rev = self.mamba_bwd(inputs_embeds=torch.flip(temporal, [1]),
                                 use_cache=False).last_hidden_state
            out = out + torch.flip(rev, [1])
        out = self.output_norm(out)

        scores = (self.temporal_attention(out).squeeze(-1)
                  + self.risk_event_attention(sequence[:, :, 4:7]).squeeze(-1))
        attention_weights = torch.softmax(scores, dim=1)
        attention_pool = torch.sum(out * attention_weights.unsqueeze(-1), dim=1)

        combined = torch.cat([attention_pool, out.mean(dim=1), out[:, -1, :],
                              static_embedding], dim=1)
        return self.classifier(combined).squeeze(-1), attention_weights


class TunableLSTM(nn.Module):
    """Your LSTM baseline, with optional bidirectional LSTM."""

    def __init__(self, temporal_features=13, static_features=12, hidden_size=64,
                 num_layers=2, dropout=0.20, bidirectional=False):
        super().__init__()
        self.bidirectional = bidirectional
        self.lstm = nn.LSTM(input_size=temporal_features, hidden_size=hidden_size,
                            num_layers=num_layers, batch_first=True,
                            dropout=dropout if num_layers > 1 else 0.0,
                            bidirectional=bidirectional)
        self.static_encoder = nn.Sequential(
            nn.Linear(static_features, 32), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(32, hidden_size), nn.ReLU()
        )
        dirs = 2 if bidirectional else 1
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * dirs + hidden_size, 64), nn.ReLU(),
            nn.Dropout(dropout), nn.Linear(64, 1)
        )

    def forward(self, sequence, static):
        _, (h, _) = self.lstm(sequence)
        temporal = torch.cat([h[-2], h[-1]], dim=1) if self.bidirectional else h[-1]
        fused = torch.cat([temporal, self.static_encoder(static)], dim=1)
        return self.classifier(fused).squeeze(-1)


# ------------------------------------------------------------
# Search spaces - 8 configs each (equal budget)
# ------------------------------------------------------------
BASE = dict(hidden_size=64, num_layers=2, dropout=0.20, lr=3e-4, weight_decay=1e-4)

SCER_CONFIGS = {
    "S1_base":          dict(BASE),
    "S2_hidden128":     dict(BASE, hidden_size=128),
    "S3_layers1":       dict(BASE, num_layers=1),
    "S4_layers3":       dict(BASE, num_layers=3),
    "S5_lr1e-3":        dict(BASE, lr=1e-3),
    "S6_reg_strong":    dict(BASE, dropout=0.30, weight_decay=1e-3),
    "S7_state32":       dict(BASE, state_size=32),
    "S8_bidirectional": dict(BASE, bidirectional=True),
}

LSTM_CONFIGS = {
    "L1_base":          dict(BASE),
    "L2_hidden128":     dict(BASE, hidden_size=128),
    "L3_layers1":       dict(BASE, num_layers=1),
    "L4_layers3":       dict(BASE, num_layers=3),
    "L5_lr1e-3":        dict(BASE, lr=1e-3),
    "L6_reg_strong":    dict(BASE, dropout=0.30, weight_decay=1e-3),
    "L7_hidden32":      dict(BASE, hidden_size=32),
    "L8_bidirectional": dict(BASE, bidirectional=True),
}

MODEL_KEYS = {"hidden_size", "num_layers", "dropout", "state_size", "bidirectional"}


def build(kind, cfg):
    kwargs = {k: v for k, v in cfg.items() if k in MODEL_KEYS}
    if kind == "SCER-Mamba":
        return TunableSCERMamba(**kwargs).to(device)
    kwargs.pop("state_size", None)
    return TunableLSTM(**kwargs).to(device)


# ------------------------------------------------------------
# Training / prediction
# ------------------------------------------------------------
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def predict(model, loader):
    model.eval()
    out = []
    with torch.no_grad():
        for seq, stat, _ in loader:
            logits = model(seq.to(device), stat.to(device))
            if isinstance(logits, tuple):
                logits = logits[0]
            out.append(torch.sigmoid(logits).cpu().numpy())
    return np.concatenate(out)


def train(kind, name, cfg, seed, max_epochs=20, patience=4):
    path = f"{OUT_DIR}/{name}_seed{seed}.pt"
    model = build(kind, cfg)
    if os.path.exists(path):
        model.load_state_dict(torch.load(path, map_location=device))
        print(f"[{name} seed {seed}] already trained - loaded")
        return model, average_precision_score(y_va, predict(model, val_loader_J24))

    set_seed(seed)
    model = build(kind, cfg)
    loader = DataLoader(train_ds, batch_size=256, shuffle=True,
                        generator=torch.Generator().manual_seed(seed),
                        num_workers=2, pin_memory=True)
    criterion = FocalLoss(gamma=2.0)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg["lr"],
                                  weight_decay=cfg["weight_decay"])

    best, bad = -1, 0
    for epoch in range(max_epochs):
        model.train()
        for seq, stat, tgt in loader:
            seq, stat, tgt = seq.to(device), stat.to(device), tgt.to(device)
            optimizer.zero_grad()
            logits = model(seq, stat)
            if isinstance(logits, tuple):
                logits = logits[0]
            loss = criterion(logits, tgt)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

        pr = average_precision_score(y_va, predict(model, val_loader_J24))
        print(f"[{name} seed {seed}] Epoch {epoch + 1:02d} | Val PR-AUC {pr:.4f}")
        if pr > best:
            best, bad = pr, 0
            torch.save(model.state_dict(), path)
        else:
            bad += 1
            if bad >= patience:
                print(f"[{name} seed {seed}] Early stopping")
                break

    model.load_state_dict(torch.load(path, map_location=device))
    return model, best


# ------------------------------------------------------------
# STEP 1 - Search (validation only, seed 42)
# ------------------------------------------------------------
done = pd.read_csv(SEARCH_CSV) if os.path.exists(SEARCH_CSV) else pd.DataFrame()

MODELS_TO_RUN = ([("LSTM", LSTM_CONFIGS)] if TUNE_LSTM else []) + [("SCER-Mamba", SCER_CONFIGS)]

for kind, configs in MODELS_TO_RUN:
    for name, cfg in configs.items():
        if len(done) and name in set(done["Config"]):
            print(f"Skipping {name} (already in search_results.csv)")
            continue
        print("\n" + "=" * 60 + f"\n{kind} | {name} | {cfg}\n" + "=" * 60)
        model, val_pr = train(kind, name, cfg, seed=42)
        val_roc = roc_auc_score(y_va, predict(model, val_loader_J24))
        row = {"Model": kind, "Config": name, "Val_PR_AUC": val_pr,
               "Val_ROC_AUC": val_roc, **{k: str(v) for k, v in cfg.items()}}
        done = pd.concat([done, pd.DataFrame([row])], ignore_index=True)
        done.to_csv(SEARCH_CSV, index=False)
        del model
        torch.cuda.empty_cache()

print("\n" + "=" * 60 + "\nSEARCH RESULTS (VALIDATION ONLY)\n" + "=" * 60)
print(done.sort_values(["Model", "Val_PR_AUC"], ascending=[True, False])
      [["Model", "Config", "Val_PR_AUC", "Val_ROC_AUC"]].round(4).to_string(index=False))


# ------------------------------------------------------------
# STEP 2 - Best config of each model -> 3 seeds -> TEST once
# ------------------------------------------------------------
def test_metrics(val_probs, test_probs):
    p, r, t = precision_recall_curve(y_va, val_probs)
    f1s = 2 * p[:-1] * r[:-1] / (p[:-1] + r[:-1] + 1e-10)
    thr = float(t[int(np.argmax(f1s))])
    pred = (test_probs >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_te, pred).ravel()
    return {"Precision": precision_score(y_te, pred, zero_division=0),
            "Recall": recall_score(y_te, pred, zero_division=0),
            "F1": f1_score(y_te, pred, zero_division=0),
            "ROC_AUC": roc_auc_score(y_te, test_probs),
            "PR_AUC": average_precision_score(y_te, test_probs),
            "TP": int(tp), "FP": int(fp), "FN": int(fn), "Threshold": thr}


seed_rows, ens_rows = [], []
for kind, configs in MODELS_TO_RUN:
    best_name = (done[done["Model"] == kind]
                 .sort_values("Val_PR_AUC", ascending=False).iloc[0]["Config"])
    cfg = configs[best_name]
    print(f"\nBEST {kind} CONFIG (by validation): {best_name} {cfg}")

    vals, tests = [], []
    for seed in [42, 123, 2026]:
        model, _ = train(kind, best_name, cfg, seed)
        vp, tp_ = predict(model, val_loader_J24), predict(model, test_loader_J24)
        vals.append(vp)
        tests.append(tp_)
        seed_rows.append({"Model": f"{kind} ({best_name})", "Seed": seed,
                          **test_metrics(vp, tp_)})
        del model
        torch.cuda.empty_cache()
    ens_rows.append({"Model": f"{kind} ({best_name}) 3-seed ensemble",
                     **test_metrics(np.mean(vals, axis=0), np.mean(tests, axis=0))})

seed_df = pd.DataFrame(seed_rows)
cols = ["Precision", "Recall", "F1", "ROC_AUC", "PR_AUC"]

print("\n" + "=" * 70 + "\nTUNED MODELS - PER-SEED TEST RESULTS\n" + "=" * 70)
print(seed_df[["Model", "Seed"] + cols + ["TP", "FP", "FN"]].round(4).to_string(index=False))

print("\n" + "=" * 70 + "\nTUNED MODELS - MEAN +/- SD OVER 3 SEEDS\n" + "=" * 70)
for model_name, g in seed_df.groupby("Model"):
    print(f"{model_name:<34} " + "  ".join(
        f"{c}: {g[c].mean():.4f} +/- {g[c].std():.4f}" for c in cols))

ens_df = pd.DataFrame(ens_rows)
print("\n" + "=" * 70 + "\nTUNED MODELS - SEED ENSEMBLES\n" + "=" * 70)
print(ens_df[["Model"] + cols + ["TP", "FP", "FN"]].round(4).to_string(index=False))

seed_df.to_csv(f"{OUT_DIR}/tuned_per_seed_test.csv", index=False)
ens_df.to_csv(f"{OUT_DIR}/tuned_ensembles_test.csv", index=False)
print(f"\nSaved all results in {OUT_DIR}/")

if not TUNE_LSTM:
    print("\nFor comparison - existing untuned LSTM (3 seeds, test): "
          "PR-AUC 0.3640 +/- 0.0037, F1 0.4518 +/- 0.0107, ROC-AUC 0.9214 +/- 0.0011")
