# ============================================================
# FINAL STEP - FINAL MODEL CHOICE, TABLE, FIGURES, ATTENTION
# ------------------------------------------------------------
# Run in the SAME Colab session right after
# final_balanced_model_J24.py has finished.
# (If Colab reset: run final_balanced_model_J24.py again first -
#  it reloads the saved models from Drive in a few minutes.)
#
#  1. Tuned SCER-Mamba with focal loss (real data), 3 seeds
#  2. Choose final model: focal vs balanced, by VALIDATION PR-AUC
#  3. Final comparison table with all baselines
#  4. Figures: model comparison, PR curves, confusion matrix,
#     balancing comparison, attention plots
# Everything is saved to Google Drive.
# ============================================================

import os
import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt
from sklearn.metrics import (
    average_precision_score, roc_auc_score, precision_recall_curve, confusion_matrix
)

for name in ["train", "train_balanced", "predict", "evaluate", "best_name", "best_cfg",
             "val_loader_J24", "test_loader_J24", "OUT_DIR", "FINAL_DIR"]:
    assert name in globals(), f"{name} missing - run final_balanced_model_J24.py first"

FIG_DIR = f"{OUT_DIR}/figures"
os.makedirs(FIG_DIR, exist_ok=True)
SEEDS = [42, 123, 2026]


# ------------------------------------------------------------
# 1. Tuned SCER-Mamba with focal loss (real class ratio)
# ------------------------------------------------------------
focal_rows, focal_val, focal_test = [], [], []
for seed in SEEDS:
    print(f"\n=== Focal loss, {best_name}, seed {seed} ===")
    model, _ = train("SCER-Mamba", best_name, best_cfg, seed)
    vp, tp_ = predict(model, val_loader_J24), predict(model, test_loader_J24)
    focal_val.append(vp)
    focal_test.append(tp_)
    focal_rows.append({"Seed": seed, "Val_PR_AUC": average_precision_score(y_va, vp),
                       **evaluate(vp, tp_)})
    del model
    torch.cuda.empty_cache()
focal_df = pd.DataFrame(focal_rows)
focal_df.to_csv(f"{FINAL_DIR}/focal_3seeds_test.csv", index=False)

# Balanced models (already trained - loaded from Drive)
bal_rows, bal_val, bal_test = [], [], []
for seed in SEEDS:
    model = train_balanced(seed)
    vp, tp_ = predict(model, val_loader_J24), predict(model, test_loader_J24)
    bal_val.append(vp)
    bal_test.append(tp_)
    bal_rows.append({"Seed": seed, "Val_PR_AUC": average_precision_score(y_va, vp),
                     **evaluate(vp, tp_)})
    del model
    torch.cuda.empty_cache()
bal_df = pd.DataFrame(bal_rows)


# ------------------------------------------------------------
# 2. Choose the final SCER-Mamba version on VALIDATION
# ------------------------------------------------------------
focal_val_pr = focal_df["Val_PR_AUC"].mean()
bal_val_pr = bal_df["Val_PR_AUC"].mean()
final_version = "Focal loss (real data)" if focal_val_pr >= bal_val_pr else "Balanced (oversampling)"
print("\n" + "=" * 70)
print(f"Validation PR-AUC - focal: {focal_val_pr:.4f} | balanced: {bal_val_pr:.4f}")
print(f"FINAL SCER-MAMBA VERSION (chosen on validation): {final_version}")
print("=" * 70)

if final_version.startswith("Focal"):
    final_val_list, final_test_list, final_seed_df = focal_val, focal_test, focal_df
else:
    final_val_list, final_test_list, final_seed_df = bal_val, bal_test, bal_df


# ------------------------------------------------------------
# 3. Final comparison table (test set)
# ------------------------------------------------------------
cols = ["Accuracy", "Precision", "Recall", "F1", "ROC_AUC", "PR_AUC"]


def mean_sd(df, label):
    row = {"Model": label}
    for c in cols:
        row[c] = f"{df[c].mean():.3f} ± {df[c].std():.3f}"
    return row


final_table = pd.DataFrame([
    mean_sd(focal_df, f"SCER-Mamba {best_name} + focal loss (3 seeds)"),
    mean_sd(bal_df, f"SCER-Mamba {best_name} + oversampling 1:1 (3 seeds)"),
    {"Model": "SCER-Mamba Experiment K (untuned, 3 seeds)", "Accuracy": "-",
     "Precision": "0.387 ± 0.010", "Recall": "0.520 ± 0.019", "F1": "0.444 ± 0.004",
     "ROC_AUC": "0.917 ± 0.002", "PR_AUC": "0.343 ± 0.012"},
    {"Model": "LSTM (untuned, 3 seeds)", "Accuracy": "-",
     "Precision": "0.405 ± 0.013", "Recall": "0.511 ± 0.020", "F1": "0.452 ± 0.011",
     "ROC_AUC": "0.921 ± 0.001", "PR_AUC": "0.364 ± 0.004"},
    {"Model": "XGBoost", "Accuracy": "-", "Precision": "0.357", "Recall": "0.545",
     "F1": "0.431", "ROC_AUC": "0.914", "PR_AUC": "0.345"},
    {"Model": "Logistic Regression", "Accuracy": "-", "Precision": "0.396", "Recall": "0.424",
     "F1": "0.410", "ROC_AUC": "0.917", "PR_AUC": "0.327"},
    {"Model": "Rule: currently 30+ days late", "Accuracy": "-", "Precision": "0.416",
     "Recall": "0.436", "F1": "0.426", "ROC_AUC": "0.715", "PR_AUC": "0.187"},
])
print("\nFINAL COMPARISON TABLE (J24 test set)")
print(final_table.to_string(index=False))
final_table.to_csv(f"{OUT_DIR}/FINAL_comparison_table.csv", index=False)


# ------------------------------------------------------------
# 4. Figures
# ------------------------------------------------------------
plt.rcParams.update({"figure.dpi": 130, "font.size": 10})

# 4a. Model comparison bar chart (PR-AUC and F1)
bar = pd.DataFrame([
    ("SCER-Mamba\n(tuned, focal)", focal_df["PR_AUC"].mean(), focal_df["F1"].mean()),
    ("SCER-Mamba\n(tuned, balanced)", bal_df["PR_AUC"].mean(), bal_df["F1"].mean()),
    ("LSTM", 0.364, 0.452),
    ("XGBoost", 0.345, 0.431),
    ("Logistic\nRegression", 0.327, 0.410),
    ("Rule\n(30+ late)", 0.187, 0.426),
], columns=["Model", "PR-AUC", "F1"])
fig, ax = plt.subplots(figsize=(10, 4.5))
x = np.arange(len(bar))
ax.bar(x - 0.2, bar["PR-AUC"], 0.4, label="PR-AUC")
ax.bar(x + 0.2, bar["F1"], 0.4, label="F1")
for i, r in bar.iterrows():
    ax.text(i - 0.2, r["PR-AUC"] + 0.005, f"{r['PR-AUC']:.3f}", ha="center", fontsize=8)
    ax.text(i + 0.2, r["F1"] + 0.005, f"{r['F1']:.3f}", ha="center", fontsize=8)
ax.set_xticks(x)
ax.set_xticklabels(bar["Model"])
ax.set_ylabel("Score (test set)")
ax.set_title("Model comparison on J24 held-out test set")
ax.legend()
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig1_model_comparison.png")
plt.show()

# 4b. Precision-recall curves
fig, ax = plt.subplots(figsize=(6, 5))
for label, probs in [("SCER-Mamba (tuned, focal)", np.mean(focal_test, axis=0)),
                     ("SCER-Mamba (tuned, balanced)", np.mean(bal_test, axis=0))]:
    p, r, _ = precision_recall_curve(y_te, probs)
    ax.plot(r, p, label=f"{label} (AP={average_precision_score(y_te, probs):.3f})")
rule = (np.asarray(X_seq_test_J24)[:, -1, 4] > 0).astype(float)
p, r, _ = precision_recall_curve(y_te, rule)
ax.plot(r, p, "--", label=f"Rule: 30+ late (AP={average_precision_score(y_te, rule):.3f})")
ax.axhline(y_te.mean(), color="grey", linestyle=":", label=f"Random ({y_te.mean():.3f})")
ax.set_xlabel("Recall")
ax.set_ylabel("Precision")
ax.set_title("Precision-recall curves (test set)")
ax.legend(fontsize=8)
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig2_pr_curves.png")
plt.show()

# 4c. Confusion matrix of the final model (3-seed ensemble)
final_eval = evaluate(np.mean(final_val_list, axis=0), np.mean(final_test_list, axis=0))
cm = np.array([[final_eval["TN"], final_eval["FP"]], [final_eval["FN"], final_eval["TP"]]])
fig, ax = plt.subplots(figsize=(4.5, 4))
ax.imshow(cm, cmap="Blues")
for i in range(2):
    for j in range(2):
        ax.text(j, i, f"{cm[i, j]:,}", ha="center", va="center",
                color="white" if cm[i, j] > cm.max() / 2 else "black", fontsize=12)
ax.set_xticks([0, 1])
ax.set_xticklabels(["Pred: not risky", "Pred: risky"])
ax.set_yticks([0, 1])
ax.set_yticklabels(["Actual: not risky", "Actual: risky"])
ax.set_title(f"Final SCER-Mamba ({final_version})")
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig3_confusion_matrix.png")
plt.show()

# 4d. Balancing comparison (earlier Experiment K results + tuned models)
bal_cmp = pd.DataFrame([
    ("Focal loss\n(no resampling)", 0.335, 0.448),
    ("Oversampling\n1:1", 0.325, 0.441),
    ("Hybrid\n20k:20k", 0.314, 0.424),
    ("Undersampling\n1:1", 0.283, 0.421),
], columns=["Method", "PR-AUC", "F1"])
fig, ax = plt.subplots(figsize=(8, 4))
x = np.arange(len(bal_cmp))
ax.bar(x - 0.2, bal_cmp["PR-AUC"], 0.4, label="PR-AUC")
ax.bar(x + 0.2, bal_cmp["F1"], 0.4, label="F1")
ax.set_xticks(x)
ax.set_xticklabels(bal_cmp["Method"])
ax.set_ylabel("Score (test set)")
ax.set_title("Imbalance-handling methods (SCER-Mamba, J24)")
ax.legend()
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig4_balancing_comparison.png")
plt.show()


# ------------------------------------------------------------
# 5. Attention plots (interpretability)
# ------------------------------------------------------------
model = train("SCER-Mamba", best_name, best_cfg, 42)[0] if final_version.startswith("Focal") \
    else train_balanced(42)
model.eval()
att_all, prob_all = [], []
with torch.no_grad():
    for seq, stat, _ in test_loader_J24:
        logits, att = model(seq.to(device), stat.to(device))
        att_all.append(att.cpu().numpy())
        prob_all.append(torch.sigmoid(logits).cpu().numpy())
att_all = np.concatenate(att_all)
prob_all = np.concatenate(prob_all)
late_30 = (np.asarray(X_seq_test_J24)[:, :, 4] > 0).astype(int)
months = np.arange(1, att_all.shape[1] + 1)

# 5a. Average attention per month: risky vs not risky
fig, ax = plt.subplots(figsize=(8, 4))
ax.plot(months, att_all[y_te == 1].mean(axis=0), marker="o", label="Risky loans")
ax.plot(months, att_all[y_te == 0].mean(axis=0), marker="o", label="Not-risky loans")
ax.set_xlabel("Month of repayment history")
ax.set_ylabel("Average attention weight")
ax.set_title("Where SCER-Mamba focuses across the 24-month history")
ax.legend()
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig5_attention_by_month.png")
plt.show()

# 5b. Attention on months with vs without a 30+ day late payment
with_late = att_all[late_30 == 1].mean() if late_30.sum() else float("nan")
without_late = att_all[late_30 == 0].mean()
print(f"\nAverage attention - months with a 30+ late payment: {with_late:.4f}")
print(f"Average attention - months without a late payment : {without_late:.4f}")
print(f"Ratio: {with_late / without_late:.2f}x more attention on late-payment months")

# 5c. Heatmap: top 8 correctly flagged risky loans
thr = final_eval["Threshold"]
idx = np.where((y_te == 1) & (prob_all >= thr))[0]
idx = idx[np.argsort(-prob_all[idx])][:8]
if len(idx):
    fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
    axes[0].imshow(att_all[idx], aspect="auto", cmap="Reds")
    axes[0].set_title("Attention weights (darker = more focus)")
    axes[1].imshow(late_30[idx], aspect="auto", cmap="Greys")
    axes[1].set_title("Months 30+ days late (black = late)")
    for a in axes:
        a.set_yticks(range(len(idx)))
        a.set_yticklabels([f"Loan {i + 1} (p={prob_all[k]:.2f})" for i, k in enumerate(idx)],
                          fontsize=8)
    axes[1].set_xticks(range(len(months)))
    axes[1].set_xticklabels(months, fontsize=8)
    axes[1].set_xlabel("Month of repayment history")
    plt.suptitle("SCER-Mamba attention vs late payments - correctly flagged risky loans")
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig6_attention_examples.png")
    plt.show()

print(f"\nAll figures saved in {FIG_DIR}/")
print(f"Final table saved as {OUT_DIR}/FINAL_comparison_table.csv")
