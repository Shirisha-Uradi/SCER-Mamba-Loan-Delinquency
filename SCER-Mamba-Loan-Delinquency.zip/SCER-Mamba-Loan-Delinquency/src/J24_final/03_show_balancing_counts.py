# ============================================================
# SHOW DATA BEFORE AND AFTER BALANCING (J24)
# Needs: /content/sequential_enhanced_model_ready_age24 (unzipped)
# ============================================================

import os
import numpy as np
import pandas as pd

FOLDER = "/content/sequential_enhanced_model_ready_age24"


def load_labels(name):
    for root, _, files in os.walk(FOLDER):
        if name in files:
            return np.load(os.path.join(root, name)).astype(int)
    raise FileNotFoundError(f"{name} not found - unzip the J24 data first")


y_train = load_labels("y_train.npy")
y_val = load_labels("y_val.npy")
y_test = load_labels("y_test.npy")


def row(name, y):
    risky, not_risky = int((y == 1).sum()), int((y == 0).sum())
    return {"Data": name, "Risky": risky, "Not risky": not_risky,
            "Total": risky + not_risky,
            "Risky %": round(100 * risky / (risky + not_risky), 2)}


# ------------------------------------------------------------
# BEFORE BALANCING - real data
# ------------------------------------------------------------
before = pd.DataFrame([row("Train", y_train),
                       row("Validation", y_val),
                       row("Test", y_test)])
print("=" * 60)
print("BEFORE BALANCING (real data)")
print("=" * 60)
print(before.to_string(index=False))


# ------------------------------------------------------------
# AFTER BALANCING - training set only (same method as experiment)
# ------------------------------------------------------------
rng = np.random.default_rng(42)
pos = np.where(y_train == 1)[0]
neg = np.where(y_train == 0)[0]

under_idx = np.concatenate([pos, rng.choice(neg, len(pos), replace=False)])
over_idx = np.concatenate([neg, pos, rng.choice(pos, len(neg) - len(pos), replace=True)])
hybrid_idx = np.concatenate([pos, rng.choice(pos, 20000 - len(pos), replace=True),
                             rng.choice(neg, 20000, replace=False)])

after = pd.DataFrame([row("Undersampling", y_train[under_idx]),
                      row("Oversampling", y_train[over_idx]),
                      row("Hybrid", y_train[hybrid_idx])])
print("\n" + "=" * 60)
print("AFTER BALANCING (training set only)")
print("=" * 60)
print(after.to_string(index=False))

print("\nValidation and test are NOT balanced:")
print(pd.DataFrame([row("Validation", y_val), row("Test", y_test)]).to_string(index=False))
