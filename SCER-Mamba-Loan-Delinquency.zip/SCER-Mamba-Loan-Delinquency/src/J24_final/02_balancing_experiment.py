# ============================================================
# BALANCING EXPERIMENT - EXPERIMENT K (MultiPoolSCERMamba) ON J24
# ------------------------------------------------------------
# Run this AFTER the J24 recovery cell (the one that defines
# MultiPoolSCERMamba, FocalLoss, X_seq_train_J24, val_loader_J24).
#
# Compares 4 ways of training:
#   1. Original      - real ratio + focal loss (your current method)
#   2. Undersampling - remove not-risky loans until 1:1
#   3. Oversampling  - repeat risky loans until 1:1
#   4. Hybrid        - 20,000 risky (oversampled) + 20,000 not risky (undersampled)
#
# Balancing is applied to the TRAINING set only.
# Validation and test keep the real ~1% ratio.
# ============================================================

import os
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import (
    average_precision_score, roc_auc_score, precision_recall_curve,
    accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
)

SEED = 42
HYBRID_SIZE = 20000
J24_FOLDER = "/content/sequential_enhanced_model_ready_age24"


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def find_file(name):
    for root, _, files in os.walk(J24_FOLDER):
        if name in files:
            return os.path.join(root, name)
    raise FileNotFoundError(f"{name} not found - re-run the J24 recovery cell first")


# ------------------------------------------------------------
# 1. Load J24 test data (train/val come from the recovery cell)
# ------------------------------------------------------------
X_seq_test_J24 = np.load(find_file("X_sequence_test.npy")).astype(np.float32)
X_static_test_J24 = np.load(find_file("X_static_test.npy")).astype(np.float32)
y_test_J24 = np.load(find_file("y_test.npy")).astype(np.float32)

test_loader_J24 = DataLoader(
    TensorDataset(
        torch.tensor(X_seq_test_J24),
        torch.tensor(X_static_test_J24),
        torch.tensor(y_test_J24)
    ),
    batch_size=1024,
    shuffle=False
)

y_train_int = np.asarray(y_train_J24).astype(int)
y_val_int = np.asarray(y_val_J24).astype(int)
y_test_int = y_test_J24.astype(int)


# ------------------------------------------------------------
# 2. Balancing - builds training indices for each method
# ------------------------------------------------------------
def make_training_indices(y, method, seed=SEED):
    rng = np.random.default_rng(seed)
    pos = np.where(y == 1)[0]
    neg = np.where(y == 0)[0]

    if method == "Original":
        idx = np.arange(len(y))

    elif method == "Undersampling":
        neg_keep = rng.choice(neg, size=len(pos), replace=False)
        idx = np.concatenate([pos, neg_keep])

    elif method == "Oversampling":
        pos_extra = rng.choice(pos, size=len(neg) - len(pos), replace=True)
        idx = np.concatenate([neg, pos, pos_extra])

    elif method == "Hybrid":
        pos_extra = rng.choice(pos, size=HYBRID_SIZE - len(pos), replace=True)
        neg_keep = rng.choice(neg, size=HYBRID_SIZE, replace=False)
        idx = np.concatenate([pos, pos_extra, neg_keep])

    else:
        raise ValueError(method)

    rng.shuffle(idx)
    return idx


METHODS = ["Original", "Undersampling", "Oversampling", "Hybrid"]
train_indices = {m: make_training_indices(y_train_int, m) for m in METHODS}


# ------------------------------------------------------------
# 3. Print label counts before / after balancing
# ------------------------------------------------------------
count_rows = []
for m in METHODS:
    y_m = y_train_int[train_indices[m]]
    count_rows.append({
        "Method": m,
        "Train risky": int(y_m.sum()),
        "Train not risky": int((y_m == 0).sum()),
        "Train risky %": round(100 * y_m.mean(), 2),
        "Val risky": int(y_val_int.sum()),
        "Val not risky": int((y_val_int == 0).sum()),
        "Test risky": int(y_test_int.sum()),
        "Test not risky": int((y_test_int == 0).sum()),
    })

counts_df = pd.DataFrame(count_rows)
print("=" * 60)
print("LABEL COUNTS BEFORE AND AFTER BALANCING")
print("=" * 60)
print(counts_df.to_string(index=False))
counts_df.to_csv("/content/balancing_label_counts.csv", index=False)


# ------------------------------------------------------------
# 4. Training / evaluation helpers
# ------------------------------------------------------------
def predict(model, loader):
    model.eval()
    probs, labels = [], []
    with torch.no_grad():
        for seq, stat, tgt in loader:
            logits, _ = model(seq.to(device), stat.to(device))
            probs.append(torch.sigmoid(logits).cpu().numpy())
            labels.append(tgt.numpy())
    return np.concatenate(probs), np.concatenate(labels).astype(int)


def best_f1_threshold(y_true, probs):
    precision, recall, thresholds = precision_recall_curve(y_true, probs)
    f1 = 2 * precision[:-1] * recall[:-1] / (precision[:-1] + recall[:-1] + 1e-10)
    i = int(np.argmax(f1))
    return float(thresholds[i])


def build_model():
    return MultiPoolSCERMamba(
        temporal_features=13,
        static_features=12,
        hidden_size=64,
        num_layers=2,
        dropout=0.20
    ).to(device)


def train_model(method, max_epochs=20, patience=4):
    set_seed(SEED)

    idx = train_indices[method]
    train_ds = TensorDataset(
        torch.tensor(np.asarray(X_seq_train_J24)[idx], dtype=torch.float32),
        torch.tensor(np.asarray(X_static_train_J24)[idx], dtype=torch.float32),
        torch.tensor(y_train_int[idx], dtype=torch.float32)
    )
    generator = torch.Generator().manual_seed(SEED)
    train_loader = DataLoader(
        train_ds, batch_size=256, shuffle=True,
        generator=generator, num_workers=2, pin_memory=True
    )

    model = build_model()

    # Original keeps focal loss; balanced sets use plain BCE
    # (using focal loss on top of balanced data would double-correct)
    criterion = FocalLoss(gamma=2.0) if method == "Original" else nn.BCEWithLogitsLoss()

    optimizer = torch.optim.AdamW(model.parameters(), lr=0.0003, weight_decay=0.0001)
    model_path = f"/content/balancing_{method}.pt"

    best_pr, no_improve = -1, 0
    for epoch in range(max_epochs):
        model.train()
        for seq, stat, tgt in train_loader:
            seq, stat, tgt = seq.to(device), stat.to(device), tgt.to(device)
            optimizer.zero_grad()
            logits, _ = model(seq, stat)
            loss = criterion(logits, tgt)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

        val_probs, val_true = predict(model, val_loader_J24)
        pr_auc = average_precision_score(val_true, val_probs)
        print(f"[{method}] Epoch {epoch + 1:02d} | Val PR-AUC {pr_auc:.4f}")

        if pr_auc > best_pr:
            best_pr, no_improve = pr_auc, 0
            torch.save(model.state_dict(), model_path)
        else:
            no_improve += 1
            if no_improve >= patience:
                print(f"[{method}] Early stopping")
                break

    model.load_state_dict(torch.load(model_path, map_location=device))
    del train_ds, train_loader
    torch.cuda.empty_cache()
    return model


def evaluate(model, method):
    # Threshold chosen on validation, then fixed for test
    val_probs, val_true = predict(model, val_loader_J24)
    threshold = best_f1_threshold(val_true, val_probs)

    test_probs, test_true = predict(model, test_loader_J24)
    preds = (test_probs >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(test_true, preds).ravel()

    return {
        "Method": method,
        "Threshold": round(threshold, 4),
        "Accuracy": accuracy_score(test_true, preds),
        "Precision": precision_score(test_true, preds, zero_division=0),
        "Recall": recall_score(test_true, preds, zero_division=0),
        "F1": f1_score(test_true, preds, zero_division=0),
        "ROC_AUC": roc_auc_score(test_true, test_probs),
        "PR_AUC": average_precision_score(test_true, test_probs),
        "TP": int(tp), "FP": int(fp), "FN": int(fn), "TN": int(tn),
    }


# ------------------------------------------------------------
# 5. Run all 4 methods and evaluate on the held-out test set
# ------------------------------------------------------------
results = []
for method in METHODS:
    print("\n" + "=" * 60)
    print("METHOD:", method)
    print("=" * 60)

    # Reuse your saved seed-42 Experiment K model for "Original" if available
    if method == "Original" and os.path.exists("/content/K_seed_42.pt"):
        print("Loading saved /content/K_seed_42.pt (no retraining needed)")
        model = build_model()
        model.load_state_dict(torch.load("/content/K_seed_42.pt", map_location=device))
    else:
        model = train_model(method)

    results.append(evaluate(model, method))
    del model
    torch.cuda.empty_cache()

results_df = pd.DataFrame(results)
print("\n" + "=" * 60)
print("HELD-OUT TEST RESULTS - J24 (EXPERIMENT K)")
print("=" * 60)
print(results_df.round(4).to_string(index=False))

results_df.to_csv("/content/balancing_test_results.csv", index=False)
print("\nSaved: /content/balancing_label_counts.csv")
print("Saved: /content/balancing_test_results.csv")
