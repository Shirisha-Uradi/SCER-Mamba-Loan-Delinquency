# Results

| Folder / file | What it is |
|---|---|
| `2023Q1/FINAL_comparison_table.csv` | Main table – all models on the J24 test set (mean ± SD over 3 seeds) |
| `2023Q1/balancing_comparison_seed42.csv` | Focal vs over / under / hybrid sampling (seed 42) |
| `2023Q1/final_balanced/focal_3seeds_test.csv` | Final SCER-Mamba S3 + focal, per seed |
| `2023Q1/final_balanced/balanced_3seeds_test.csv` | Final SCER-Mamba S3 + oversampling 1:1, per seed |
| `2023Q1/final_balanced/balanced_ensemble_test.csv` | 3-seed ensemble of the oversampled model |
| `2023Q1/final_balanced/balanced_label_counts.csv` | Label counts before / after balancing |
| `tuning/search_results.csv` | Architecture search S1–S8 (validation PR-AUC) |
| `2015Q1/table_history_length_means.csv` | History-length study, 3-seed means, all metrics |
| `2015Q1/significance_scer_vs_lstm.csv` | Bootstrap p-values per history length |
| `2015Q1/experiment_B_categorical_48m.csv` | Experiment B (categorical features) |
| `2015Q1/experiment_B_significance.txt` | Experiment B bootstrap test |
| `2015Q1/experiment_C_multitask_partial.csv` | Experiment C status (in progress) |
| `early_vscode/` | Outputs of the local Phase 1–2 scripts (12-month data, ablations, J18/J24, Experiment K) |

`balancing_comparison_seed42.csv`, `significance_scer_vs_lstm.csv`, `experiment_B_categorical_48m.csv` and `experiment_C_multitask_partial.csv` were transcribed from the Colab console output; empty cells = not printed in that run.
